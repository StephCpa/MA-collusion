"""Offline descriptive analysis of delayed responses in a frozen X2 run.

The registered X2 estimand is the responder's round-11 action.  This script
does not replace that estimand.  It summarizes the post-impulse model rounds
(rounds 12--29) as a descriptive check for a delayed response.  Round 10 is
the one-round intervention and round 11 is the registered immediate response;
neither is included in this delayed window.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List


MODEL_ROUNDS = tuple(range(12, 30))
ARMS = ("N0", "N1", "H0", "H1")


def _load_rows(run_dir: Path) -> List[Dict[str, Any]]:
    path = run_dir / "rows.json"
    rows = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(rows, list):
        raise ValueError("rows.json must contain a list")
    return rows


def _classify(price: float, forced_price: float = 5.5) -> str:
    if price < forced_price:
        return "strict_undercut"
    if price == forced_price:
        return "match"
    return "accommodate"


def summarize(rows: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    rows = list(rows)
    by_arm = {arm: [row for row in rows if row.get("condition") == arm] for arm in ARMS}
    if any(len(by_arm[arm]) != 48 for arm in ARMS):
        raise ValueError("expected 48 rows in each X2 arm")

    result: Dict[str, Any] = {
        "run_type": "x2_delayed_window_descriptive",
        "registered_estimand": "round_11",
        "model_rounds": list(MODEL_ROUNDS),
        "arms": {},
    }
    for arm in ARMS:
        arm_rows = by_arm[arm]
        responder_counts: Dict[str, Dict[str, int]] = {}
        categories: Dict[str, Dict[str, int]] = {}
        for round_no in MODEL_ROUNDS:
            prices: List[float] = []
            for row in arm_rows:
                event = next((event for event in row["events"] if event["round"] == round_no), None)
                if event is None:
                    raise ValueError(f"missing round {round_no} in block {row.get('block')}")
                prices.append(float(event["prices"][row["responder"]]))
            counts = Counter(f"{price:.1f}" for price in prices)
            responder_counts[str(round_no)] = dict(sorted(counts.items()))
            if arm in ("N1", "H1"):
                categories[str(round_no)] = dict(
                    sorted(Counter(_classify(price) for price in prices).items())
                )
        all_six = all(
            responder_counts[str(round_no)] == {"6.0": 48}
            for round_no in MODEL_ROUNDS
        )
        result["arms"][arm] = {
            "n_blocks": len(arm_rows),
            "responder_price_counts": responder_counts,
            "intervention_categories": categories,
            "all_rounds_responder_6.0": all_six,
        }
    result["all_arms_all_rounds_responder_6.0"] = all(
        result["arms"][arm]["all_rounds_responder_6.0"] for arm in ARMS
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    summary = summarize(_load_rows(args.run_dir))
    text = json.dumps(summary, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
