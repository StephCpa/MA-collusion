"""Offline P0 re-analysis for the controlled-initial history study.

This script reads the frozen continuation ledger only.  It deliberately does
not issue provider calls and does not overwrite the registered analysis.  The
outputs are descriptive sensitivity analyses requested during manuscript
review: simple natural -> hide-rival contrasts, round-0/round-1 decomposition,
exact tie rates, and the action distribution conditional on a displayed rival
price of 6.5.
"""
from __future__ import annotations

import json
import math
import random
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, stdev

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "artifacts/controlled-initial-history/20260927-deepseek-flash-v02-continuation1/run/cells.json"
OUT = ROOT / "research/results/reviewer-revision-20260930"
GRID = {2.0 + 0.5 * i for i in range(10)}
ASSESSMENT = range(10, 30)


def q(x: float) -> float:
    """Round only for stable JSON/report output."""
    return round(float(x), 10)


def welfare(minimum: float) -> float:
    # Demand is 100*(10-p)/9 and total surplus is CS + industry profit.
    return 100.0 * (10.0 - minimum) * (10.0 - 1.0) / 9.0


def normal_ci(values: list[float]) -> list[float]:
    """Small-sample descriptive t-style interval without SciPy dependency."""
    if not values:
        return [None, None]
    m = mean(values)
    if len(values) < 2:
        return [q(m), q(m)]
    # 95% normal approximation is labelled descriptive, never registered.
    se = stdev(values) / math.sqrt(len(values))
    return [q(m - 1.96 * se), q(m + 1.96 * se)]


def bootstrap(values: list[float], seed: int = 20260930, draws: int = 20000) -> list[float]:
    if not values:
        return [None, None]
    if len(values) == 1:
        return [q(values[0]), q(values[0])]
    rng = random.Random(seed)
    n = len(values)
    means = [mean(rng.choices(values, k=n)) for _ in range(draws)]
    means.sort()
    return [q(means[int(0.025 * draws)]), q(means[int(0.975 * draws) - 1])]


def price(event: dict, seller: str) -> float:
    return float(event["prices"][seller]["price"])


def trajectory_summary(row: dict) -> dict:
    events = {int(event["round"]): event for event in row.get("events", [])}
    if row.get("status") != "completed" or any(r not in events for r in range(30)):
        raise ValueError(f"incomplete trajectory: {row.get('block')} {row.get('cell')}")
    initial = events[0]["prices"]
    initial_state = (float(initial["seller_a"]["price"]), float(initial["seller_b"]["price"]))
    assessment_events = [events[r] for r in ASSESSMENT]
    mins = [min(price(e, "seller_a"), price(e, "seller_b")) for e in assessment_events]
    ties = [price(e, "seller_a") == price(e, "seller_b") for e in assessment_events]
    round1 = events[1]
    round1_a, round1_b = price(round1, "seller_a"), price(round1, "seller_b")
    return {
        "block": int(row["block"]),
        "cell": row["cell"],
        "initial_state": [q(x) for x in initial_state],
        "round1_state": [q(round1_a), q(round1_b)],
        "round1_tie": round1_a == round1_b,
        "assessment_tie_fraction": mean(ties),
        "assessment_min_mean": mean(mins),
        "assessment_welfare_mean": mean(welfare(x) for x in mins),
        "assessment_min_6_0_fraction": mean(x == 6.0 for x in mins),
        "assessment_min_6_5_fraction": mean(x == 6.5 for x in mins),
        "assessment_rounds": len(assessment_events),
    }


def conditional_action_counts(row: dict) -> dict:
    """Classify current action when the immediately prior rival price is 6.5."""
    events = {int(event["round"]): event for event in row.get("events", [])}
    counts = Counter()
    observations = 0
    for r in range(1, 30):
        if r - 1 not in events or r not in events:
            continue
        current, previous = events[r], events[r - 1]
        for seller, rival in (("seller_a", "seller_b"), ("seller_b", "seller_a")):
            if price(previous, rival) != 6.5:
                continue
            observations += 1
            p = price(current, seller)
            if p == 6.5:
                counts["match_6.5"] += 1
            elif p == 6.0:
                counts["one_step_undercut_6.0"] += 1
            elif p == 5.5:
                counts["profit_max_undercut_5.5"] += 1
            else:
                counts["other"] += 1
    result = {key: counts[key] for key in ("match_6.5", "one_step_undercut_6.0", "profit_max_undercut_5.5", "other")}
    result["observations"] = observations
    result["fractions"] = {key: q(result[key] / observations) if observations else None for key in result if key != "observations"}
    return result


def paired_contrast(summaries: dict[int, dict[str, dict]], cell: str, field: str) -> dict:
    natural = summaries_by_block(summaries, f"{cell}-natural")
    hidden = summaries_by_block(summaries, f"{cell}-hide_rival")
    common = sorted(set(natural) & set(hidden))
    # Positive means hide-rival minus natural, matching the research question.
    values = [hidden[b][field] - natural[b][field] for b in common]
    return {
        "complete_pairs": len(values),
        "estimand": "hide_rival minus natural",
        "mean": q(mean(values)) if values else None,
        "sample_sd": q(stdev(values)) if len(values) > 1 else 0.0,
        "descriptive_normal_ci": normal_ci(values),
        # Avoid Python's process-randomized hash so repeated runs are byte-stable.
        "paired_bootstrap_ci": bootstrap(values, seed=20260930 + sum(ord(c) for c in f"{cell}:{field}")) if values else [None, None],
        "positive_pairs": sum(v > 0 for v in values),
        "zero_pairs": sum(v == 0 for v in values),
        "negative_pairs": sum(v < 0 for v in values),
    }


def summaries_by_block(summaries: dict[int, dict[str, dict]], cell: str) -> dict[int, dict]:
    return {block: values[cell] for block, values in summaries.items() if cell in values}


def load_rows() -> list[dict]:
    rows = json.loads(SOURCE.read_text(encoding="utf-8"))
    if not isinstance(rows, list) or not rows:
        raise AssertionError("cells.json must contain a non-empty list")
    return rows


def main() -> None:
    rows = load_rows()
    summaries: dict[int, dict[str, dict]] = defaultdict(dict)
    conditional_raw: dict[str, Counter] = defaultdict(Counter)
    conditional_obs: Counter = Counter()
    incomplete = []
    for row in rows:
        try:
            summary = trajectory_summary(row)
        except ValueError:
            incomplete.append({"block": row.get("block"), "cell": row.get("cell"), "status": row.get("status")})
            continue
        summaries[summary["block"]][summary["cell"]] = summary
        row_conditional = conditional_action_counts(row)
        cell = summary["cell"]
        conditional_obs[cell] += row_conditional["observations"]
        for key in ("match_6.5", "one_step_undercut_6.0", "profit_max_undercut_5.5", "other"):
            conditional_raw[cell][key] += row_conditional[key]

    # A block is usable for a cell contrast only when both arms are present.
    cells = sorted({cell for per_block in summaries.values() for cell in per_block})
    round1 = {}
    assessment = {}
    for cell in cells:
        values = [per_block[cell] for per_block in summaries.values() if cell in per_block]
        round1[cell] = {
            "trajectories": len(values),
            "state_counts": {str(list(state)): count for state, count in sorted(Counter(tuple(v["round1_state"]) for v in values).items(), key=str)},
            "tie_rate": q(mean(v["round1_tie"] for v in values)),
        }
        assessment[cell] = {
            "trajectories": len(values),
            "tie_rate_mean": q(mean(v["assessment_tie_fraction"] for v in values)),
            "minimum_price_mean": q(mean(v["assessment_min_mean"] for v in values)),
            "welfare_mean": q(mean(v["assessment_welfare_mean"] for v in values)),
            "min_6_0_fraction": q(mean(v["assessment_min_6_0_fraction"] for v in values)),
            "min_6_5_fraction": q(mean(v["assessment_min_6_5_fraction"] for v in values)),
        }

    simple = {}
    for cell in ("LH", "HL"):
        simple[cell] = {
            field: paired_contrast(summaries, cell, field)
            for field in ("assessment_welfare_mean", "assessment_min_mean", "assessment_tie_fraction", "round1_tie")
        }

    conditional = {}
    for cell in cells:
        observations = conditional_obs[cell]
        counts = {key: conditional_raw[cell][key] for key in ("match_6.5", "one_step_undercut_6.0", "profit_max_undercut_5.5", "other")}
        conditional[cell] = {
            **counts,
            "observations": observations,
            "fractions": {key: q(value / observations) if observations else None for key, value in counts.items()},
        }

    output = {
        "scope": "offline post-hoc P0 sensitivity analysis; no provider calls; registered estimands unchanged",
        "source": str(SOURCE.relative_to(ROOT)),
        "rows": len(rows),
        "completed_trajectories": sum(len(per_block) for per_block in summaries.values()),
        "excluded_incomplete_trajectories": incomplete,
        "round0": {
            "by_cell": {
                cell: sorted({tuple(v["initial_state"]) for per_block in summaries.values() for c, v in per_block.items() if c == cell})
                for cell in cells
            },
            "interpretation": "round 0 is programmed and identical across paired arms; it cannot mediate an arm effect",
        },
        "round1_by_arm": round1,
        "assessment_by_arm": assessment,
        "simple_contrasts_hide_minus_natural": simple,
        "conditional_on_previous_rival_6.5": conditional,
        "guardrails": {
            "inferential_unit": "paired block",
            "intervals": "descriptive normal and paired bootstrap sensitivities",
            "not_a_registered_estimand": True,
            "does_not_identify_collusion_or_T4": True,
        },
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "p0-derived-analysis.json").write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    lines = [
        "# P0-derived offline re-analysis (2026-09-30)",
        "",
        "This report is post-hoc and reads only the frozen continuation ledger. It does not alter the registered estimands and made zero provider calls.",
        "",
        f"- Source rows: {len(rows)}; completed trajectories: {output['completed_trajectories']}",
        "- Inferential unit: paired block; intervals are descriptive sensitivity intervals.",
        "- Round 0 is programmed, so the arm contrast begins at round 1.",
        "",
        "## Simple natural -> hide-rival contrasts",
        "",
        "Positive values are hide-rival minus natural. The two asymmetric cells show the structural effect on ties while the minimum-price contrast remains small.",
        "",
        "| Initial cell | outcome | pairs | mean | bootstrap 95% interval |",
        "|---|---:|---:|---:|---:|",
    ]
    labels = {
        "assessment_welfare_mean": "assessment welfare",
        "assessment_min_mean": "assessment minimum price",
        "assessment_tie_fraction": "assessment tie fraction",
        "round1_tie": "round-1 tie indicator",
    }
    for cell in ("LH", "HL"):
        for field, label in labels.items():
            item = simple[cell][field]
            lines.append(f"| {cell} | {label} | {item['complete_pairs']} | {item['mean']:.4f} | [{item['paired_bootstrap_ci'][0]:.4f}, {item['paired_bootstrap_ci'][1]:.4f}] |")
    lines += [
        "",
        "## Round-1 decomposition",
        "",
        "Round 0 is identical within each paired cell. The arm differences therefore first appear in the first model decision; this is a descriptive mediation check, not a causal mediation estimate.",
        "",
        "| arm | trajectories | round-1 state counts | round-1 tie rate |",
        "|---|---:|---|---:|",
    ]
    for cell in cells:
        item = round1[cell]
        states = "; ".join(f"{state}: {count}" for state, count in item["state_counts"].items())
        lines.append(f"| {cell} | {item['trajectories']} | {states} | {item['tie_rate']:.4f} |")
    lines += [
        "",
        "## Conditional choice when the previous rival price is 6.5",
        "",
        "This tabulation separates matching from one-step and profit-maximizing undercutting; it is descriptive and conditions on an observed history.",
        "",
        "| arm | observations | match 6.5 | undercut 6.0 | undercut 5.5 | other |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for cell in cells:
        item = conditional[cell]
        f = item["fractions"]
        lines.append(f"| {cell} | {item['observations']} | {f['match_6.5'] if f['match_6.5'] is not None else 'NA'} | {f['one_step_undercut_6.0'] if f['one_step_undercut_6.0'] is not None else 'NA'} | {f['profit_max_undercut_5.5'] if f['profit_max_undercut_5.5'] is not None else 'NA'} | {f['other'] if f['other'] is not None else 'NA'} |")
    lines += [
        "",
        "## Interpretation boundary",
        "",
        "The decomposition is consistent with the main paper's aggregation-blind-spot result: display changes joint-price structure while the minimum-price endpoint is often pinned. It does not establish a strategic objective, punishment, deterrence, collusion, or harmful coordination.",
        "",
        "The machine-readable result is `p0-derived-analysis.json`; the source ledger remains unchanged.",
    ]
    (OUT / "p0-derived-analysis.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"passed": True, "output": str(OUT / "p0-derived-analysis.json"), "rows": len(rows), "completed": output["completed_trajectories"]}, indent=2))


if __name__ == "__main__":
    main()
