"""Offline-first X2 forced-deviation protocol runner and analyzer.

No provider/client is imported here.  The module is deliberately a deterministic
protocol simulator and ledger validator; a paid launch must be implemented by a
separate, explicitly authorised adapter.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from itertools import product
from pathlib import Path
import json, random, hashlib

CONDITIONS = ("N0", "N1", "H0", "H1")

@dataclass(frozen=True)
class Manifest:
    protocol: str = "X2-forced-deviation-20260929"
    mode: str = "offline"
    paid_calls_authorized: bool = False
    blocks: int = 48
    forced_a_blocks: int = 24
    forced_b_blocks: int = 24
    trajectories: int = 192
    rounds: int = 30
    prelude_rounds: int = 10
    shock_round: int = 10
    forced_price: float = 5.5
    price_grid: tuple = (2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5)
    retries: int = 0
    repair: bool = False

@dataclass
class LedgerEntry:
    block: int
    condition: str
    forced_seller: str
    complete: bool = True
    failed_calls: int = 0
    cap_reserved: bool = False
    retries: int = 0
    repair: bool = False

def build_manifest() -> dict:
    """Return a JSON-serializable manifest and reject any paid configuration."""
    m = asdict(Manifest())
    m["price_grid"] = list(m["price_grid"])
    return m

def observation_surface(condition: str, own_history, rival_history=None) -> dict:
    if condition not in CONDITIONS: raise ValueError(condition)
    out = {"own_posted_prices": list(own_history), "condition": condition}
    if condition.startswith("N"):
        out["rival_posted_prices"] = list(rival_history or [])
    # Outcomes are intentionally never included.
    return out

def execute_action(condition: str, seller: str, round_no: int, requested: float,
                   forced_seller: str) -> tuple[float, bool]:
    forced = condition in ("N1", "H1") and round_no == 10 and seller == forced_seller
    return (5.5 if forced else requested), forced

def synthetic_trajectory(condition: str, forced_seller="A", responder_round11=6.0,
                         shadow_round10=6.0, block=1) -> dict:
    """Create an auditable, no-call trajectory for tests and dry runs."""
    events=[]
    prices={"A":[6.0]*10, "B":[6.0]*10}
    for r in range(30):
        req={"A":6.0,"B":6.0}
        if r == 11: req["A" if forced_seller=="B" else "B"] = responder_round11
        for s in ("A","B"):
            executed, forced = execute_action(condition,s,r,req[s],forced_seller)
            if r == 10: req[s] = shadow_round10
            events.append({"round":r,"seller":s,"condition":condition,
                "requested_action":req[s],"executed_action":executed,"forced":forced,
                "visible_history":observation_surface(condition,prices[s],prices["B" if s=="A" else "A"]),
                "call_status":"synthetic"})
            prices[s].append(executed)
    return {"block":block,"condition":condition,"forced_seller":forced_seller,
            "events":events,"complete":True}

def validate_ledger(entries) -> dict:
    entries=list(entries); errors=[]
    if any(e.retries or e.repair for e in entries): errors.append("retry_or_repair_present")
    blocks={}
    for e in entries: blocks.setdefault(e.block,[]).append(e)
    for b, es in blocks.items():
        if {e.condition for e in es} != set(CONDITIONS): errors.append(f"block_{b}_incomplete")
    forced={"A":sum(e.forced_seller=="A" for e in entries),"B":sum(e.forced_seller=="B" for e in entries)}
    return {"valid":not errors,"errors":errors,"blocks":len(blocks),"forced_counts":forced,
            "complete_blocks":sum(len(es)==4 and all(e.complete for e in es) for es in blocks.values()),
            "failed_calls":sum(e.failed_calls for e in entries),"cap_reserved":sum(e.cap_reserved for e in entries)}

def analyze_interaction(rows) -> dict:
    """Compute cut5 and non-accommodating 2x2 interaction from round-11 response."""
    vals={c:[] for c in CONDITIONS}
    for row in rows:
        c=row["condition"]
        r=row.get("round11", row.get("responder_round11"))
        if c in vals and r is not None: vals[c].append(float(r))
    def p(c, pred): return sum(pred(x) for x in vals[c])/len(vals[c]) if vals[c] else float("nan")
    def interaction(pred): return (p("N1",pred)-p("N0",pred))-(p("H1",pred)-p("H0",pred))
    cats={c:{"punish":p(c,lambda x:x<5.5),"match":p(c,lambda x:x==5.5),"accommodate":p(c,lambda x:x>5.5)} for c in CONDITIONS}
    return {"n":{c:len(vals[c]) for c in CONDITIONS},"categories":cats,
            "cut5_interaction":interaction(lambda x:x<5.5),
            "non_accommodating_interaction":interaction(lambda x:x<=5.5)}

def self_test() -> dict:
    checks=[]
    for c in CONDITIONS:
        t=synthetic_trajectory(c)
        forced=[e for e in t["events"] if e["round"]==10 and e["seller"]=="A"][0]
        checks.append((c, forced["forced"], forced["executed_action"]))
    assert checks[0][1:] == (False,6.0) and checks[1][1:] == (True,5.5)
    for c in ("H0","H1"):
        assert all("rival_posted_prices" not in e["visible_history"] for e in synthetic_trajectory(c)["events"])
    rows=[{"condition":c,"round11":(5.0 if c=="N1" else 6.0)} for c in CONDITIONS for _ in range(20)]
    assert analyze_interaction(rows)["cut5_interaction"] == 1.0
    return {"passed":True,"checks":["intervention","hidden_surface","interaction"]}

if __name__ == "__main__":
    print(json.dumps({"manifest":build_manifest(),"self_test":self_test()}, indent=2))
