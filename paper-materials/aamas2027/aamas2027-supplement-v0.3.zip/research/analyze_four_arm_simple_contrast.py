"""Recompute the declared post-hoc natural -> hide-rival contrast.

The four-arm history-display experiment and the later controlled-initial study
are different estimands.  This script reads the sealed four-arm trajectory
ledger, restricts to complete four-arm blocks, and recomputes the simple
contrast as hide-rival minus natural.  It makes no provider calls and never
replaces the registered factorial main effect.
"""
from __future__ import annotations

import json
import math
import random
from pathlib import Path
from statistics import mean, stdev

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "artifacts/history-channel-formal/20260922-deepseek-flash-v021/trajectories/ledger.json"
OUT = ROOT / "research/results/reviewer-revision-20260930"
ARMS = ("natural", "hide_rival", "hide_own", "hide_both")


def q(x: float) -> float:
    return round(float(x), 10)


def interval(values: list[float]) -> list[float]:
    if len(values) < 2:
        return [q(mean(values)), q(mean(values))] if values else [None, None]
    se = stdev(values) / math.sqrt(len(values))
    return [q(mean(values) - 1.96 * se), q(mean(values) + 1.96 * se)]


def bootstrap(values: list[float], draws: int = 20000) -> list[float]:
    if not values:
        return [None, None]
    if len(values) == 1:
        return [q(values[0]), q(values[0])]
    rng = random.Random(20260930)
    n = len(values)
    means = sorted(mean(rng.choices(values, k=n)) for _ in range(draws))
    return [q(means[int(0.025 * draws)]), q(means[int(0.975 * draws) - 1])]


def load_complete_block_summaries() -> dict[int, dict[str, float]]:
    data = json.loads(SOURCE.read_text(encoding="utf-8"))
    by_block: dict[int, dict[str, float]] = {}
    for arm in data["arms"]:
        if arm.get("status") != "complete" or len(arm.get("events", [])) != 30:
            continue
        block = int(arm["block"])
        welfare = mean(float(event["total_welfare"]) for event in arm["events"][10:30])
        by_block.setdefault(block, {})[arm["arm"]] = welfare
    return by_block


def main() -> None:
    by_block = load_complete_block_summaries()
    complete_four_arm = {
        block: values for block, values in by_block.items() if all(arm in values for arm in ARMS)
    }
    values = [v["hide_rival"] - v["natural"] for v in complete_four_arm.values()]
    result = {
        "scope": "post-hoc declared simple contrast; no provider calls; registered factorial main effect unchanged",
        "source": str(SOURCE.relative_to(ROOT)),
        "arm_means_aggregated_within_block": True,
        "assessment_rounds": "10-29 inclusive",
        "complete_four_arm_blocks": len(complete_four_arm),
        "estimand": "hide_rival minus natural",
        "mean": q(mean(values)) if values else None,
        "sample_sd": q(stdev(values)) if len(values) > 1 else 0.0,
        "descriptive_normal_ci": interval(values),
        "paired_bootstrap_ci": bootstrap(values),
        "positive_blocks": sum(v > 0 for v in values),
        "zero_blocks": sum(v == 0 for v in values),
        "negative_blocks": sum(v < 0 for v in values),
        "registered_factorial_main_effect_for_comparison": {
            "reported_mean": 4.053030303030308,
            "reported_bonferroni_interval": [-0.31391842729968733, 8.41997903336026]
        },
        "guardrails": {
            "post_hoc": True,
            "not_substituted_for_registered_main_effect": True,
            "does_not_identify_collusion_or_T4": True,
        },
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "four-arm-simple-contrast.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# Four-arm post-hoc simple contrast (2026-09-30)",
        "",
        "This offline re-analysis uses only complete four-arm blocks from the sealed ledger. It does not replace the registered factorial main effect and made zero provider calls.",
        "",
        f"- Complete four-arm blocks: {result['complete_four_arm_blocks']}",
        "- Estimand: hide-rival minus natural, with welfare averaged within each block over rounds 10--29.",
        f"- Mean contrast: **{result['mean']:.3f}**",
        f"- Descriptive normal 95% interval: [{result['descriptive_normal_ci'][0]:.3f}, {result['descriptive_normal_ci'][1]:.3f}]",
        f"- Paired bootstrap 95% interval: [{result['paired_bootstrap_ci'][0]:.3f}, {result['paired_bootstrap_ci'][1]:.3f}]",
        f"- Positive / zero / negative blocks: {result['positive_blocks']} / {result['zero_blocks']} / {result['negative_blocks']}",
        "",
        "The registered factorial main effect remains a different estimand (reported mean 4.053; Bonferroni interval [-0.314, 8.420]). The simple contrast is therefore a declared post-hoc deviation, not confirmatory evidence for a general welfare effect. Neither estimand identifies collusion or T4 harmful coordination.",
    ]
    (OUT / "four-arm-simple-contrast.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"passed": True, "complete_four_arm_blocks": len(complete_four_arm), "mean": result["mean"]}, indent=2))


if __name__ == "__main__":
    main()
