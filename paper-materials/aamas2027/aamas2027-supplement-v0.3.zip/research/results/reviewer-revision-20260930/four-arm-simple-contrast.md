# Four-arm post-hoc simple contrast (2026-09-30)

This offline re-analysis uses only complete four-arm blocks from the sealed ledger. It does not replace the registered factorial main effect and made zero provider calls.

- Complete four-arm blocks: 44
- Estimand: hide-rival minus natural, with welfare averaged within each block over rounds 10--29.
- Mean contrast: **11.070**
- Descriptive normal 95% interval: [5.711, 16.429]
- Paired bootstrap 95% interval: [5.634, 16.340]
- Positive / zero / negative blocks: 20 / 20 / 4

The registered factorial main effect remains a different estimand (reported mean 4.053; Bonferroni interval [-0.314, 8.420]). The simple contrast is therefore a declared post-hoc deviation, not confirmatory evidence for a general welfare effect. Neither estimand identifies collusion or T4 harmful coordination.
