# P0-derived offline re-analysis (2026-09-30)

This report is post-hoc and reads only the frozen continuation ledger. It does not alter the registered estimands and made zero provider calls.

- Source rows: 384; completed trajectories: 380
- Inferential unit: paired block; intervals are descriptive sensitivity intervals.
- Round 0 is programmed, so the arm contrast begins at round 1.

## Simple natural -> hide-rival contrasts

Positive values are hide-rival minus natural. The two asymmetric cells show the structural effect on ties while the minimum-price contrast remains small.

| Initial cell | outcome | pairs | mean | bootstrap 95% interval |
|---|---:|---:|---:|---:|
| LH | assessment welfare | 47 | 1.0638 | [0.0000, 3.1915] |
| LH | assessment minimum price | 47 | -0.0106 | [-0.0319, 0.0000] |
| LH | assessment tie fraction | 47 | -0.8851 | [-0.9606, -0.7915] |
| LH | round-1 tie indicator | 47 | -0.4681 | [-0.6170, -0.3191] |
| HL | assessment welfare | 48 | 1.3542 | [0.0000, 3.6458] |
| HL | assessment minimum price | 48 | -0.0135 | [-0.0375, 0.0000] |
| HL | assessment tie fraction | 48 | -0.8531 | [-0.9385, -0.7531] |
| HL | round-1 tie indicator | 48 | -0.6250 | [-0.7500, -0.4792] |

## Round-1 decomposition

Round 0 is identical within each paired cell. The arm differences therefore first appear in the first model decision; this is a descriptive mediation check, not a causal mediation estimate.

| arm | trajectories | round-1 state counts | round-1 tie rate |
|---|---:|---|---:|
| HH-hide_rival | 47 | [6.5, 6.5]: 47 | 1.0000 |
| HH-natural | 48 | [6.5, 6.5]: 48 | 1.0000 |
| HL-hide_rival | 48 | [6.5, 5.5]: 1; [6.5, 6.0]: 46; [6.5, 6.5]: 1 | 0.0208 |
| HL-natural | 48 | [6.0, 6.0]: 30; [6.5, 6.0]: 17; [6.5, 6.5]: 1 | 0.6458 |
| LH-hide_rival | 47 | [6.0, 6.5]: 47 | 0.0000 |
| LH-natural | 48 | [6.0, 6.0]: 23; [6.0, 6.5]: 24; [6.5, 6.0]: 1 | 0.4792 |
| LL-hide_rival | 48 | [6.0, 6.0]: 48 | 1.0000 |
| LL-natural | 46 | [6.0, 6.0]: 46 | 1.0000 |

## Conditional choice when the previous rival price is 6.5

This tabulation separates matching from one-step and profit-maximizing undercutting; it is descriptive and conditions on an observed history.

| arm | observations | match 6.5 | undercut 6.0 | undercut 5.5 | other |
|---|---:|---:|---:|---:|---:|
| HH-hide_rival | 2726 | 1.0 | 0.0 | 0.0 | 0.0 |
| HH-natural | 2784 | 1.0 | 0.0 | 0.0 | 0.0 |
| HL-hide_rival | 1393 | 0.0014357502 | 0.9978463747 | 0.0007178751 | 0.0 |
| HL-natural | 360 | 0.175 | 0.825 | 0.0 | 0.0 |
| LH-hide_rival | 1363 | 0.0 | 1.0 | 0.0 | 0.0 |
| LH-natural | 314 | 0.178343949 | 0.821656051 | 0.0 | 0.0 |
| LL-hide_rival | 0 | NA | NA | NA | NA |
| LL-natural | 0 | NA | NA | NA | NA |

## Interpretation boundary

The decomposition is consistent with the main paper's aggregation-blind-spot result: display changes joint-price structure while the minimum-price endpoint is often pinned. It does not establish a strategic objective, punishment, deterrence, collusion, or harmful coordination.

The machine-readable result is `p0-derived-analysis.json`; the source ledger remains unchanged.
