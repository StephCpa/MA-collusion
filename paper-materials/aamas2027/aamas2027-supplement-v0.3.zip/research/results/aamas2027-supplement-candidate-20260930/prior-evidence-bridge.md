# Prior evidence bridge for the AAMAS supplement

This record maps already completed studies to the X1/X2 evidence ladder. It is
not a pooled analysis and does not replace the new controlled Flash experiments.

## Evidence inventory

| artifact | model / design | supports | cannot support |
|---|---|---|---|
| `papers/deepseek-endgame-history-probe-result-v1.0.md` | Flash and Pro, externally fixed rival, terminal versus continuing frame | a prompt-level test of costly matching and current-profit competence in an earlier grid | a valid repeated-game sustainability test; the original punishment horizon was theoretically too weak |
| `papers/deepseek-pro-deviation-restoration-result-v1.0.md` | Pro, matched Force/Placebo, 30-round closed loop | a model-family-specific local response to a forced price change and rapid high-price restoration | a response for the current Flash controlled-initial deployment; no punishment-region entry was observed |
| `papers/deepseek-pro-attribution-repetition-result-v1.0.md` | Pro, attribution by repetition | whether provenance/repetition strengthened the earlier response | a general absence of response or a cross-model mechanism |
| `papers/current-progress-summary-en.md` | cross-study synthesis | why capability, local response, and temporal transportability must be separated | a single pooled strategic-coordination estimate |

## Integration rule

These studies may appear in the supplement as **external mechanism context**,
with model family, action grid, operating point, and protocol stated separately.
They must not be averaged with X1/X2, used to fill a missing Flash cell, or
described as a replication unless the exact prompt, deployment, action grid,
and response estimand match.

## AAMAS narrative value

The completed record already supports a useful negative-control lesson: a model
can react to a forced deviation and restore a high-price path without entering a
declared punishment region. This makes the distinction between “reactive
dependence” and “strategically sustained harmful coordination” concrete. X1/X2
are still needed because the current paper's main deployment and information
surface must be tested directly.

## Reporting order

1. Report the controlled Flash observability result as the primary contribution.
2. Report X1 as a capability qualification, if completed.
3. Report X2 as a local causal response test, if completed.
4. Use prior Pro/earlier-Flash studies only as a clearly labeled robustness and
   boundary subsection.
5. Keep the strong T4 label conditional on the declared deviation, response
   classification, and harm endpoint; a restoration trace alone is insufficient.
