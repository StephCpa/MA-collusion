# Manuscript integration plan for X1/X2

This file is a writing map, not a result record. It deliberately contains no
behavioral numbers from paid calls.

## Evidence allocation

| experiment | evidence class | independent unit | main-text role | supplementary material |
|---|---|---|---|---|
| X1 terminal competence | necessary support | prompt ID cluster | one sentence establishing whether a current-profit capability gate passed | full action distribution, Wilson intervals, cluster bootstrap |
| X1 continuing frame | qualification | prompt ID cluster | only if the competence gate passes; label as forbearance-compatible | prompt hashes and cell-level ledger |
| X2 round-11 response | core discovery if non-zero | four-condition block | primary response category and interaction | all response categories and completion bounds |
| X2 persistence | qualification | four-condition block | only if it changes the local-response interpretation | trajectory traces and sensitivity windows |

## Claim rules

### If X1 competence fails

Use: “The current-profit competence gate was not established in one or more
terminal cells; continuing departures therefore cannot be interpreted as
forbearance.”

Do not use: “the model strategically chose not to deviate,” “the model colluded,”
or “the model lacks strategic ability” as a general claim.

### If X1 passes and the horizon gap is positive

Use: “Under an externally fixed rival and a declared continuing frame, the model
showed a horizon-sensitive, costly matching response compatible with
forbearance.”

Do not use: “dynamic optimum,” “punishment,” “agreement,” or “collusion.”

### If X2 interaction is positive

Use: “A forced one-period undercut changed the responder's pre-specified action
distribution relative to a matched no-shock control, and the response differed
by rival-price visibility.”

Then report whether the response was `punish`, `match`, or `accommodate`.
Only a response classified as strict undercutting can enter a punishment-facing
discussion; matching or accommodation is not silently recoded.

### If X2 interaction is null or imprecise

Use: “The local deviation-response interaction was not resolved at the registered
effect size.”

Retain the T2/T3 observability result. Do not convert the X2 null into evidence
that no strategic coordination exists.

## Planned display

The preferred supplemental display is a two-panel figure:

1. X1: terminal versus continuing action probabilities for each rival price,
   with prompt-ID cluster intervals;
2. X2: four-arm round-11 response categories and the registered interaction,
   with complete-block denominators.

The main paper should add at most one paragraph and one compact table. Full
prompt text, request hashes, model fingerprints, missingness ledger, and all
secondary persistence outcomes remain in supplementary material.

## Analysis discipline

X1 and X2 are not pooled with the existing controlled-initial estimands. The
same model alias does not imply the same deployment: returned model identity and
system fingerprint are reported as strata. No manuscript edit may insert a
positive mechanism claim before `analysis.json` and the audit ledger exist for
the corresponding run.
