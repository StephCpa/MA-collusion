# X1 live result: competence versus forbearance

**Protocol:** `protocols/x1-competence-forbearance-best-response-v0.1-candidate.md`  
**Run:** replacement namespace `x1-replacement-20260930`  
**Status:** complete and audited; 576/576 valid responses  
**Model:** `deepseek-flash`; returned model was uniform across calls  
**System fingerprint:** `aeb56401ca74e127821c4f9126dcb669`

## Registered result

The current-profit best response was 5.5 in both rival-price cells. In the
terminal frame, the model selected 5.5 in 144/144 draws for both rival prices;
the call-level Wilson 95% lower bound was 0.974 in each cell. Because the
registered contrast uses 48 prompt-ID clusters per cell (three draws per ID),
the corresponding conservative 48/48 cluster-level Wilson lower reference is
0.926. The competence gate therefore passed; the 0.974 value is retained as a
delivery calibration rather than a cluster-population interval.

| rival price | terminal BR | continuing BR | BR gap | 95% cluster-bootstrap interval |
|---:|---:|---:|---:|---:|
| 6.0 | 1.000 | 1.000 | 0.000 | [0.000, 0.000] |
| 6.5 | 1.000 | 0.993 | 0.0069 | [0.000, 0.0208] |
| pooled | — | — | 0.0035 | [0.000, 0.0104] |

The inferential unit is the prompt ID (48 clusters per rival-price cell), not
the 144 individual calls in a terminal cell. Each cluster averages its three
pre-specified draws before the paired bootstrap; the draws are repeated calls
within a prompt ID and are not counted as independent replicates. The pooled
quantity is the equal-weight average of the two cell-level gaps, with the
cell-specific cluster resampling retained in the sensitivity interval.

The two zero-width intervals are a property of the observed cluster support:
every terminal and continuing draw was non-matching, so every bootstrap
resample has the same matching gap. They are therefore degenerate resampling
intervals, not a claim that the population gap is known to equal zero. For a
finite-sample reference, 0 matching events in 144 independent calls would
give a one-sided 95% binomial upper bound of
`1 - 0.05^(1/144) = 0.0206`; this bound is not substituted for the
cluster-level registered estimand and does not remove the prompt-ID dependence.

The pooled continuing-minus-terminal matching gap was 0.000 with interval
[0.000, 0.000]. The continuing frame therefore did not produce the registered
horizon-sensitive costly-matching pattern. The single non-5.5 continuing draw
occurred in the rival-6.5 cell and selected 6.0; it does not change the
classification.

## Interpretation

The result rules out a simple explanation in which the main-study matching
pattern is primarily caused by inability to compute the current-profit best
response in this controlled prompt. It does **not** show that the model is
dynamically rational, and it does not identify collusion, punishment, or intent.
The cleanest bounded interpretation is that the main trajectory's costly
matching must be studied as a history/transition phenomenon rather than as a
generic one-shot arithmetic failure. X2 is the registered test of that local
causal response.

## Accounting and audit

- Prompt IDs: 48 per rival-price cell; three draws per horizon.
- Planned and usable calls: 576 and 576.
- Network attempts from the quarantined first launch are excluded; that incident
  is recorded separately and was never retried under the same logical ID.
- Replacement accounted cost: 1.116864 CNY under the peak-price ledger formula
  (the run occurred in the provider's idle window, so this is a conservative
  planning charge rather than a claim about an invoice).
- No API key, raw credential, or hidden reasoning is stored.
