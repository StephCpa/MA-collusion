# X2 live result: forced-deviation impulse response

**Protocol:** `research/x2-forced-deviation-protocol-20260929.md`  
**Run:** `x2-live-20260930T0638+0800`  
**Status:** complete and audited; 192/192 trajectories and 48/48 blocks  
**Model:** `deepseek-flash`; 7,680/7,680 delivered requests  
**System fingerprint:** `aeb56401ca74e127821c4f9126dcb669`

## Registered result

The forced seller was overwritten to 5.5 at round 10 in all 96 intervention
trajectories. All 96 shadow/executed intervention records were present and exact;
no control trajectory carried a forced flag. The responder's round-11 action was
6.0 in every arm:

| arm | responder `R=6.0` | strict undercut `R<5.5` | match `R=5.5` | accommodate `R>5.5` |
|---|---:|---:|---:|---:|
| N0 natural / no shock | 48/48 | 0/48 | 0/48 | 48/48 |
| N1 natural / forced 5.5 | 48/48 | 0/48 | 0/48 | 48/48 |
| H0 hidden rival / no shock | 48/48 | 0/48 | 0/48 | 48/48 |
| H1 hidden rival / forced 5.5 | 48/48 | 0/48 | 0/48 | 48/48 |

The registered interactions were therefore:

```text
I_cut5 = 0.000, 95% block-bootstrap interval [0.000, 0.000]
I_non_accommodating = 0.000, 95% block-bootstrap interval [0.000, 0.000]
```

Both intervals are degenerate block-bootstrap intervals: all 48 complete
blocks have the same four-cell response pattern, so every resample returns
zero. They should not be read as population certainty or as an exact upper
bound on a response probability. As a finite-sample calibration, 0 events in
48 independent blocks has a one-sided 95% binomial upper bound of
`1 - 0.05^(1/48) = 0.0605` (6.05%). This bound describes an event rate under
an independence model; it is not a replacement for the registered 2x2
interaction, whose inferential unit remains the matched block.

## Interpretation

At the tested `(6.0, 6.0)` prelude, one-period forced movement of the designated
seller to 5.5 did not change the other seller's next-round action. The result is
an informative local null for this operating point, intervention size, response
window, and model deployment. It does not establish that no strategic response
exists under another target, deviation size, horizon, or model family, and it
does not convert the absence of a response into proof against all coordination
mechanisms.

Combined with X1, the result weakens two simple explanations for the main-study
pattern: current-profit competence was established, yet neither a continuing
frame nor this exogenous local deviation produced the registered response. The
main paper can therefore retain the T2/T3 observability claim while keeping T4
unidentified.

## Accounting and audit

- 48 blocks, balanced 24 forced-seller-A and 24 forced-seller-B blocks.
- 192 trajectories, 30 rounds each; 10-round programmatic prelude and 20 model
  rounds.
- 7,680 model calls; no retries, repairs, unresolved requests, or missing
  blocks.
- 7,680 request files passed the prompt-surface audit: hidden arms contained no
  rival prices, natural arms retained them, and no realized outcome field was
  present.
- Accounted cost: 16.162512 CNY in the ledger formula; the run was executed in
  the provider's idle window, so the recorded amount is retained as the
  conservative peak-price accounting value.
