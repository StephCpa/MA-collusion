# X2 delayed-response analysis (rounds 12--29)

**Run:** `x2-live-20260930T0638+0800`  
**Source:** `rows.json` (192 trajectories; 48 complete four-condition blocks)  
**Scope:** offline read-only analysis; no provider calls and no changes to the manuscript.

## Estimand and an important timing qualification

The post-shock window is rounds 12--29 inclusive (18 rounds per trajectory). The
intervention was a one-round impulse at round 10: in N1 and H1 the designated
seller was overwritten to 5.5 at round 10, then was released to model control.
Thus, `forced seller = 5.5` is the shock target, not the seller's maintained
price throughout rounds 12--29. In the delayed window the released seller's
realized price was 6.0 in every observation in all four arms. N0 and H0 did not
receive a forced 5.5 event and are therefore controls, not additional treated
responses to a 5.5 state.

For the target-relative classification below, the responder's price is compared
with 5.5:

* **strict undercut:** responder price `< 5.5`;
* **match:** responder price `= 5.5`;
* **accommodate:** responder price `> 5.5`.

This classification is useful for describing persistence after the impulse, but
it must not be read as evidence that a 5.5 state was still present in rounds
12--29.

## Exact counts

Each arm has 48 trajectories, one per block, and 18 post-shock rounds, giving
864 responder-round observations per arm (3,456 across arms).

| arm | blocks / trajectories | responder `<5.5` | responder `=5.5` | responder `>5.5` | all-18-round accommodate blocks |
|---|---:|---:|---:|---:|---:|
| N0 | 48 / 48 | 0 / 864 | 0 / 864 | 864 / 864 | 48 / 48 |
| N1 | 48 / 48 | 0 / 864 | 0 / 864 | 864 / 864 | 48 / 48 |
| H0 | 48 / 48 | 0 / 864 | 0 / 864 | 864 / 864 | 48 / 48 |
| H1 | 48 / 48 | 0 / 864 | 0 / 864 | 864 / 864 | 48 / 48 |

The result is constant by round: for every `t = 12, ..., 29`, each arm has
48/48 responder actions at 6.0, hence 48/48 `>5.5`, with no strict undercut or
match.

The actual counterpart comparison gives the same result in the delayed window:

| arm | counterpart price in rounds 12--29 | responder = counterpart |
|---|---:|---:|
| N0 | 864 / 864 at 6.0 | 864 / 864 |
| N1 | 864 / 864 at 6.0 | 864 / 864 |
| H0 | 864 / 864 at 6.0 | 864 / 864 |
| H1 | 864 / 864 at 6.0 | 864 / 864 |

The shock itself is also present exactly where registered: N1 and H1 have
48/48 forced 5.5 actions at round 10; N0 and H0 have 0/48. At round 11, the
responder is 6.0 in all 48 trajectories in each arm. The released counterpart
is 6.0 in all round-11 observations except one N1 trajectory, where the model
also selected 5.5 without a force flag; this incidental action is outside the
round-12--29 estimand.

## Appropriate analysis unit

The block is the primary independent unit. A block contains the matched N0,
N1, H0, and H1 trajectories and shares the environment seed and forced-seller
orientation. The 18 rounds are repeated observations within a trajectory, not
18 independent samples. The most conservative block-level summaries are
therefore:

* all four arms: 48/48 blocks have zero undercuts, zero matches, and 18/18
  accommodate observations relative to the 5.5 target;
* all four arms: 48/48 blocks have responder = released counterpart in every
  round 12--29.

If an inferential interval is desired for the descriptive all-18-round block
indicator, the two-sided 95% Clopper--Pearson lower bound for 48/48 is 0.9260.
This is a bound on the fraction of blocks satisfying that stringent indicator,
not a round-level confidence interval and not a test of a general strategic
response mechanism.

For the complementary zero-event statement, 0 strict undercuts (or 0 matches)
in 48 independent block indicators has a one-sided 95% binomial upper bound of
`1 - 0.05^(1/48) = 0.0605`. This is a finite-sample calibration only. It does
not treat the 18 repeated rounds within a trajectory as independent and does
not replace the registered block-level interaction analysis.

## Interpretation boundary

The delayed window supplies a clean persistence check: after the one-period
5.5 impulse, no arm produced a responder action below or equal to 5.5 in the
next 18 rounds. It does **not** identify a punishment response, a deterrence
mechanism, or the absence of coordination in general. The intervention is local
to a `(6.0, 6.0)` prelude, a single 5.5 deviation, a fixed model deployment,
and a response window beginning two rounds after the impulse. The forced seller
was not held at 5.5 during the analyzed window, so the result cannot distinguish
failure to react from rapid restoration of the operating point by the released
seller.

The appropriate manuscript-facing wording is therefore: *“In the registered
post-impulse window (rounds 12--29), all 48 blocks in each arm showed responder
prices of 6.0 in every round; relative to the 5.5 shock target this is 864/864
accommodating observations per arm. This is a local delayed-response null for
the tested operating point and impulse, not evidence against strategic
coordination more broadly.”*
