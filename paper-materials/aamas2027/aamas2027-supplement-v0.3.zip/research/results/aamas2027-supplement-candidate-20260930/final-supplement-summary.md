# Supplemental experiment summary (2026-09-30)

This file is the handoff record for the two reviewer-facing supplements now
integrated into the AAMAS staging manuscript. It records what was tested,
what was observed, and what the results do **not** establish.

## X1: current-profit competence versus continuing-frame matching

- Run: `x1-live-replacement-20260930T0628+0800`
- Model: `deepseek-flash`; returned fingerprint
  `aeb56401ca74e127821c4f9126dcb669`
- Planned and usable calls: 576 / 576
- Status: complete, frozen, and audited

The current-profit best response was 5.5 for both rival-price cells. The
terminal frame selected 5.5 in 144/144 draws for rival prices 6.0 and 6.5;
the Wilson 95% lower bound was 0.974 in each cell. The pooled continuing-minus-
terminal best-response gap was 0.0035 with cluster-bootstrap interval
[0.0000, 0.0104]. The pooled costly-matching gap was 0.0000 with interval
[0.0000, 0.0000].

Bounded interpretation: the main-study matching pattern is not explained by a
generic inability to compute the current-profit best response in this prompt.
The probe does not establish dynamic rationality, collusion, punishment, or
intent.

## X2: forced-deviation impulse response

- Run: `x2-live-20260930T0638+0800`
- Model: `deepseek-flash`; returned fingerprint
  `aeb56401ca74e127821c4f9126dcb669`
- Blocks / trajectories / delivered requests: 48 / 192 / 7,680
- Status: complete, frozen, and audited

The experiment programmed a ten-round `(6.0, 6.0)` prelude and forced one
designated seller to 5.5 at round 10 in the intervention arms. The responder's
round-11 action was 6.0 in all four arms (N0, N1, H0, H1), 48/48 in each arm.
Both registered interactions were exactly zero:

```text
I_cut5 = 0.000, 95% block-bootstrap interval [0.000, 0.000]
I_non_accommodating = 0.000, 95% block-bootstrap interval [0.000, 0.000]
```

As a separate descriptive delayed-window check, the frozen trajectories were
also inspected from rounds 12--29, after the round-10 impulse and registered
round-11 response. The responder selected 6.0 in all 18 post-impulse rounds in
all four arms (48/48 per arm per round); the intervention arms had zero strict
undercuts and zero matches at every inspected round. The forced seller was
released after round 10 and returned to model control, so this is a local
persistence null rather than a test of response to a maintained 5.5 state. It
is not a new registered estimand or a T4 test.

Bounded interpretation: at the tested prelude, intervention size, one-period
response window, and deployment, the forced movement did not change the other
seller's next-round action. This is a local null, not evidence that all
strategic response or coordination mechanisms are absent.

## Manuscript consequence

Together X1 and X2 support the following restrained claim: current-profit
competence is present, while the registered continuing-frame and local
forced-deviation response tests are null. The manuscript may retain the T2/T3
observability result and the aggregation-blind-spot argument, but should keep
T4 harmful strategic coordination unassigned. No claim about a general
monitoring error rate, collusion, punishment, or model intent is licensed.

## Reproducibility and incidents

The first X1 launch timed out before a response and is quarantined in
`x1-live-20260930T0622+0800/incident.md`; it was not retried under the same
logical IDs and is excluded from all estimates. The replacement run reserved
its ledger before network calls and completed without unresolved requests. X2
passed the full prompt-surface and request-ledger audit. The delayed-window
record is `x2-live-20260930T0638+0800/delayed-response-analysis.md`, with a
machine-readable companion `delayed-window-analysis.json`. No API key or
private credential is stored in the artifacts.

## Cost accounting

The conservative peak-price ledger records 1.116864 CNY for X1 and 16.162512
CNY for X2. Both runs occurred in the provider's idle window, so these values
are planning/accounting upper bounds rather than invoice claims. The pricing
reference used by the protocol is the official
[DeepSeek pricing page](https://api-docs.deepseek.com/zh-cn/quick_start/pricing/).

## Next decision

Do not launch X3/X4 automatically. The next high-value step is manuscript and
artifact consistency checking against the official AAMAS template. A new paid
run is justified only if the paper needs a broader operating-point test (for
example, a surplus-bearing target or an extended price grid) to make a claim
that the present local evidence cannot support.
