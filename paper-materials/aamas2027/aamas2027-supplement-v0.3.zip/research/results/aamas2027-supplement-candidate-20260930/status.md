# X1 launch status (2026-09-30)

## G0 offline gate

**Passed.** The deterministic X1 runner and mock positive-control report passed
the registered manifest, payoff argmax, prompt-surface, parser, balance, and
determinism checks.

- planned calls: 576
- offline tests: 4 passed
- request-ledger tests (existing): 30 passed in the combined targeted run
- valid model responses: 0
- network attempts: 1 (timeout; billing unknown)

An attempted first launch at 06:22 received a connection timeout before any
response. That attempt is quarantined as an implementation incident because
the pre-fix runner reserved too late; see
`x1-live-20260930T0622+0800/incident.md`. It is not a result and must not be
resumed.

## Launch blocker

The current process now obtains the user-level variable only for an ephemeral
child process. The first network attempt timed out at the provider connection
layer. The corrected runner now reserves before connecting and terminally
records unknown transport outcomes. Any replacement launch must use a new output
directory and schedule seed; do not paste the key into a file or command
history.
