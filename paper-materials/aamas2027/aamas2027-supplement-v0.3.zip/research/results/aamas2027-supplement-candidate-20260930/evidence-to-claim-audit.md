# Evidence-to-claim audit for the AAMAS staging manuscript

*Updated 2026-10-01 for supplement v0.2: replication, T3a/T3b split, operating-point gate, and cluster-level Wilson wording.*

This checklist separates what is directly identified from what remains outside
the evidence boundary. It should be rerun after any manuscript or protocol
change.

| Claim layer | Current evidence | Independent unit | Status | Allowed wording |
|---|---|---|---|---|
| T1 structural observability | Full 10x10 grid: 100 ordered states collapse into 10 classes with identical `(market_min, welfare, CS, industry_profit)`; seller rewards and HHI differ within classes. | Exhaustive state enumeration plus one ledger-round check | **Passed** | Aggregate welfare is not a complete monitor of joint-action/allocation state under this settlement rule. |
| T1 welfare contrast | Controlled-initial block contrasts are small and structurally constrained by the minimum-price rule. | Complete block / amended trajectory ledger | **Descriptive** | Do not call this a general null or a proof of no harm. |
| T2 joint-action structure | Natural versus hide-rival asymmetric cells differ in equal-price persistence and transition direction; fixed-history order effect reverses with rival background. | Block/trajectory-level summaries | **Passed, bounded** | Display changes observable joint-action structure without explicit messages. |
| T2 replication (Candidate A, added 2026-10-01) | Protocol structural primary D_tie = 0.830, 95% block-t [0.743, 0.917], 42/42 blocks positive; completion range [0.792, 0.841]. Same deployment and fingerprint. | Complete block | **Passed, within deployment** | The structural contrast replicated; not a cross-model result. |
| T3a/T3b allocation | Seller-level profit/HHI differs even when aggregate welfare is identical; reported by direction as T3a capture concentration (HHI 1.00) and T3b market division (equal split at a tie, HHI 0.50). | Ledger rounds / blocks | **Passed, bounded** | Display moves asymmetric cells from T3a capture toward T3b division; neither endpoint is a collusion certificate. |
| X1 capability gate | Terminal current-profit BR = 1.000 (144/144 per rival-price cell), Wilson lower bound 0.926 at the 48-cluster level (call-level calibration 0.974); pooled BR gap 0.0035 [0, 0.0104]. | Prompt-ID cluster | **Passed** | Main-study costly matching is not explained by a generic one-shot arithmetic failure in this controlled prompt. |
| X2 local response | Forced 5.5 at round 10 after a `(6.0,6.0)` prelude; responder chose 6.0 in 48/48 blocks in every arm; both registered interactions exactly 0 [0,0]. | Complete four-arm block | **Local null** | No tested next-round response at this operating point; no claim about all strategic responses. |
| X2 delayed window | After the round-10 impulse and registered round-11 snapshot, the responder chose 6.0 in every post-impulse round 12--29 in all four arms; intervention arms had no strict undercuts or matches. The forced seller was released after round 10. | Complete four-arm block, descriptive window | **Exploratory local null** | No delayed response after the impulse within this short window; not a test of a maintained 5.5 state or a registered T4 estimand. |
| T4 harmful coordination | No surplus-bearing, benchmark-relative deviation/punishment response certificate at the manuscript's operating point. | Not observed | **Unassigned** | Do not claim collusion, punishment, intent, absorbing states, or a general false-negative rate. |
| T4 operating-point gate (added 2026-10-01) | Arithmetic gate: (i) supra-competitive vs grid-Nash, (ii) profitable deviation, (iii) tie at or below the 5.5 joint-profit price. Observed 6.0/6.5 ties and the X2 (6.0, 6.0) prelude pass (i)-(ii) and fail (iii). | Exact enumeration | **Gate not met** | A deviation test at these points cannot separate strategic sustainment from anchoring. |

## Audit checks completed

1. X1 replacement ledger: 576/576 delivered responses; returned model and
   fingerprint uniform; quarantined first-launch timeout excluded.
2. X2 ledger: 7,680/7,680 delivered requests; 48/48 complete blocks; forced
   seller balanced; exact round-10 intervention; no hidden-arm rival leakage;
   no realized outcome field in prompts.
3. Manuscript integration: X1/X2 are reported as supplementary, local tests;
   neither is pooled with the original controlled-initial estimands.
4. Statistical language: confidence intervals use the registered prompt-ID or
   block bootstrap units; zero-width intervals are reported as observed local
   nulls, not as universal absence claims.

## Remaining evidence gap

The paper still lacks a T4 test at a surplus-bearing operating point with an
explicit deviation gain and a response rule. The highest-value future run is
therefore not another copy of X2, but a preregistered operating-point/grid
extension if the manuscript needs to make a strategic-sustainment claim.
