# AAMAS 2027 supplement: offline cost quote

This is a planning quote only. It records no API calls and is not an invoice
cap. The official DeepSeek pricing page lists `deepseek-flash` at 2 CNY per
million uncached input tokens and 8 CNY per million output tokens during peak
hours; idle-hour prices are half of peak. The page also states that prices may
change, so the quote must be refreshed immediately before launch.

Source: <https://api-docs.deepseek.com/zh-cn/quick_start/pricing/> (checked
2026-09-30).

The same page currently maps the request name `deepseek-flash` to the
DeepSeek-V4.1-Flash serving model. This quote therefore applies to the alias at
launch time; the returned model and system fingerprint must be retained.

## Formula

`cost = calls * (input_tokens * input_price + output_tokens * output_price) / 1,000,000`

The table brackets the expected prompt growth by 2,000 and 4,000 input tokens
per call and reserves 256 output tokens per call. It excludes any calibration
calls, failed requests, or provider-side tokenization differences.

| package | calls | peak at 2k input | peak at 4k input | idle at 2k input | idle at 4k input |
|---|---:|---:|---:|---:|---:|
| X1 | 576 | 3.48 CNY | 5.79 CNY | 1.74 CNY | 2.89 CNY |
| X2 | 7,680 | 46.45 CNY | 77.17 CNY | 23.23 CNY | 38.59 CNY |
| X1 + X2 | 8,256 | 49.93 CNY | 82.96 CNY | 24.97 CNY | 41.48 CNY |
| X3 (optional) | 5,760 | 34.84 CNY | 57.88 CNY | 17.42 CNY | 28.94 CNY |
| X4 (optional) | 11,520 | 69.67 CNY | 115.75 CNY | 34.84 CNY | 57.88 CNY |

For approval, use a rounded cap of **100 CNY for X1+X2**, plus any separately
approved calibration reserve. The runner must stop before the cap is exceeded,
must not retry a charged request, and must write the live token usage into the
ledger. The final charge is determined by actual token usage, not this quote.
