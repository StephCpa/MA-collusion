"""Offline initial-state and imitation-baseline sensitivity analysis.

This analysis is deliberately model-free with respect to the API: it reads the
sealed EXP-045 trajectories and enumerates deterministic candidate policies on
the original price grid.  It addresses a reviewer concern that high-price ties
may be explained by copying, inertia, or the selected initial state rather than
by a strategic coordination mechanism.

The closed-loop section is a counterfactual rule stress test, not an estimate
of the LLM policy.  It enumerates every ordered initial pair on the grid.  The
held-out section reports action matches on the recorded trajectories using the
existing trajectory-level leave-one-out audit.
"""
from __future__ import annotations

import argparse
import json
import sys
from itertools import product
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_STUDY = ROOT / "artifacts/autonomous-propensity/20260911T075911Z-glm53-coding-autonomous-propensity-forced-tool"
AGENTS = ("seller_a", "seller_b")
ASSESSMENT_START = 10


def load_study(study: Path) -> list[dict[str, Any]]:
    index = [json.loads(line) for line in (study / "trajectory-index.jsonl").read_text(encoding="utf-8").splitlines()]
    runs = []
    for row in index:
        run_dir = study / "runs" / row["run_id"]
        config = json.loads((run_dir / "effective_config.json").read_text(encoding="utf-8"))
        events = []
        for line in (run_dir / "events.jsonl").read_text(encoding="utf-8").splitlines():
            event = json.loads(line)
            if event.get("event_type") == "step":
                events.append(event)
        if len(events) != config["experiment"]["rounds"]:
            raise ValueError("Round count mismatch: " + row["run_id"])
        runs.append({"index": row, "config": config, "events": events})
    return runs


def grid_of(run: dict[str, Any]) -> tuple[float, ...]:
    return tuple(float(p) for p in run["config"]["environment"]["allowed_prices"])


def env_params(run: dict[str, Any]) -> tuple[float, float, float]:
    env = run["config"]["environment"]
    return float(env["marginal_cost"]), float(env["reservation_price"]), float(env["market_size"])


def pair(event: dict[str, Any]) -> tuple[float, float]:
    return float(event["actions"]["seller_a"]["price"]), float(event["actions"]["seller_b"]["price"])


def unilateral_profit(price: float, rival: float, cost: float, reservation: float, market_size: float) -> float:
    if price > rival:
        return 0.0
    quantity = market_size * max(0.0, (reservation - price) / (reservation - cost))
    share = 0.5 if abs(price - rival) < 1e-9 else 1.0
    return (price - cost) * quantity * share


def br_price(rival: float, grid: tuple[float, ...], cost: float, reservation: float, market_size: float) -> float:
    scores = {p: unilateral_profit(p, rival, cost, reservation, market_size) for p in grid}
    best = max(scores.values())
    return max(p for p, score in scores.items() if abs(score - best) < 1e-9)


def undercut(rival: float, grid: tuple[float, ...]) -> float:
    lower = [p for p in grid if p < rival]
    return max(lower) if lower else min(grid)


def predict(rule: str, agent: str, history: tuple[float, float], grid: tuple[float, ...], cost: float, reservation: float, market_size: float) -> float:
    own, rival = history if agent == "seller_a" else (history[1], history[0])
    if rule == "simultaneous_myopic_br":
        return br_price(rival, grid, cost, reservation, market_size)
    if rule == "mechanical_undercut":
        return undercut(rival, grid)
    if rule == "match_if_equal_else_copy_rival":
        return own if own == rival else rival
    if rule == "match_if_equal_else_undercut":
        return own if own == rival else undercut(rival, grid)
    if rule == "inertia_own_price":
        return own
    raise KeyError(rule)


def closed_loop(rule: str, grid: tuple[float, ...], cost: float, reservation: float, market_size: float, initial: tuple[float, float], steps: int = 30) -> dict[str, Any]:
    history = tuple(initial)
    path = [history]
    for _ in range(steps):
        nxt = (predict(rule, "seller_a", history, grid, cost, reservation, market_size), predict(rule, "seller_b", history, grid, cost, reservation, market_size))
        if nxt == history:
            break
        history = nxt
        path.append(history)
    return {"initial": list(initial), "path": [list(p) for p in path], "updates_to_absorbing": len(path) - 1, "terminal": list(path[-1]), "absorbing": True}


RULES = (
    "simultaneous_myopic_br",
    "mechanical_undercut",
    "match_if_equal_else_copy_rival",
    "match_if_equal_else_undercut",
    "inertia_own_price",
)
SELECTED_INITIALS = ((2.0, 2.0), (3.0, 3.0), (4.0, 4.0), (5.5, 5.5), (6.0, 6.0), (6.5, 6.5), (6.0, 6.5))


def _initial_key(initial: tuple[float, float]) -> str:
    return f"({initial[0]:g}, {initial[1]:g})"


def _closed_loop_summary(rule: str, grid: tuple[float, ...], cost: float, reservation: float, market_size: float) -> dict[str, Any]:
    rows = [closed_loop(rule, grid, cost, reservation, market_size, initial) for initial in __import__("itertools").product(grid, grid)]
    by_initial = {tuple(r["initial"]): r for r in rows}
    equal = [r for r in rows if r["initial"][0] == r["initial"][1]]
    unequal = [r for r in rows if r["initial"][0] != r["initial"][1]]
    return {
        "rule": rule,
        "grid_initials": len(rows),
        "max_updates_to_absorbing": max(r["updates_to_absorbing"] for r in rows),
        "equal_initials": len(equal),
        "equal_initials_preserved": sum(tuple(r["terminal"]) == tuple(r["initial"]) for r in equal),
        "unequal_initials_converge_to_equal": sum(r["terminal"][0] == r["terminal"][1] for r in unequal),
        "unequal_initials_converge_to_floor": sum(tuple(r["terminal"]) == (min(grid), min(grid)) for r in unequal),
        "selected_initials": {
            _initial_key(init): by_initial[init]
            for init in SELECTED_INITIALS
            if init in by_initial
        },
        "terminal_counts": {
            _initial_key(tuple(k)): n
            for k, n in __import__("collections").Counter(tuple(r["terminal"]) for r in rows).most_common()
        },
    }


def _transition_surface(runs: list[dict[str, Any]], grid: tuple[float, ...]) -> dict[str, Any]:
    """Summarize copying/inertia/undercutting on observed unequal states.

    Only transitions whose previous pair is unequal are used.  We count each
    seller separately, and only model-generated rounds (the programmed round
    zero has no preceding state).
    """
    records: list[dict[str, Any]] = []
    for run in runs:
        events = run["events"]
        for idx in range(1, len(events)):
            previous = pair(events[idx - 1])
            current = pair(events[idx])
            if previous[0] == previous[1]:
                continue
            for agent, pos in (("seller_a", 0), ("seller_b", 1)):
                own, rival, action = previous[pos], previous[1 - pos], current[pos]
                lower = [p for p in grid if p < rival]
                one_step_undercut = max(lower) if lower else min(grid)
                records.append(
                    {
                        "agent": agent,
                        "previous": list(previous),
                        "action": action,
                        "copy_rival": action == rival,
                        "inertia_own": action == own,
                        "one_step_undercut": action == one_step_undercut,
                        "assessment": events[idx]["round"] >= 10,
                    }
                )
    def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
        n = len(rows)
        return {
            "observations": n,
            "copy_rival_rate": sum(r["copy_rival"] for r in rows) / n if n else None,
            "inertia_own_rate": sum(r["inertia_own"] for r in rows) / n if n else None,
            "one_step_undercut_rate": sum(r["one_step_undercut"] for r in rows) / n if n else None,
        }
    return {
        "all_rounds": summarize(records),
        "assessment_rounds": summarize([r for r in records if r["assessment"]]),
        "previous_pair_counts": {
            _initial_key(tuple(k)): n
            for k, n in __import__("collections").Counter(tuple(r["previous"]) for r in records).most_common()
        },
    }


def _held_out_match(runs: list[dict[str, Any]], rule: str, grid: tuple[float, ...], cost: float, reservation: float, market_size: float) -> float:
    """Mean per-trajectory match rate for non-parametric rules.

    Every trajectory is held out from rule construction because these rules have
    no fitted parameters.  The averaging convention matches the parent audit:
    compute one assessment rate per trajectory, then average across trajectories.
    """
    rates = []
    for run in runs:
        events = run["events"]
        matches = 0
        n = 0
        for idx, event in enumerate(events):
            if event["round"] < ASSESSMENT_START or idx == 0:
                continue
            previous = pair(events[idx - 1])
            predicted = (
                predict(rule, "seller_a", previous, grid, cost, reservation, market_size),
                predict(rule, "seller_b", previous, grid, cost, reservation, market_size),
            )
            actual = pair(event)
            matches += int(predicted[0] == actual[0]) + int(predicted[1] == actual[1])
            n += 2
        if n:
            rates.append(matches / n)
    return sum(rates) / len(rates) if rates else float("nan")


def analyze(study: Path) -> dict[str, Any]:
    study = Path(study)
    runs = load_study(study)
    grid = grid_of(runs[0])
    cost, reservation, market_size = env_params(runs[0])
    closed = {
        rule: _closed_loop_summary(rule, grid, cost, reservation, market_size)
        for rule in RULES
    }
    exclusion = {
        rule: {
            "mean_assessment_match_rate": _held_out_match(runs, rule, grid, cost, reservation, market_size),
            "cannot_exclude_as_exact_generator": False,
        }
        for rule in RULES
    }
    return {
        "analysis": "initial_state_baseline_sensitivity",
        "network_calls": 0,
        # Keep packaged artifacts anonymous and portable.  The raw absolute
        # checkout path is intentionally not written to the result.
        "study": str(study.resolve().relative_to(ROOT)).replace("\\", "/") if study.resolve().is_relative_to(ROOT) else study.name,
        "n_trajectories": len(runs),
        "grid": list(grid),
        "closed_loop_counterfactual": closed,
        "held_out_action_match": exclusion,
        "observed_unequal_state_transitions": _transition_surface(runs, grid),
        "interpretation": {
            "high_price_ties_are_not_identified_by_welfare_or_ties_alone": True,
            "copying_and_inertia_are_heuristic_alternatives_not_strategic_proof": True,
            "low_and_mid_initial_states_are_counterfactual_baseline_support_not_new_llm_observations": True,
        },
    }


def render(result: dict[str, Any]) -> str:
    lines = [
        "# Offline initial-state and imitation-baseline sensitivity",
        "",
        "This report uses sealed EXP-045 trajectories and deterministic counterfactual rules only; `network_calls=0`. The closed-loop grid enumerates every ordered initial pair on the original grid. It is a stress test of heuristic explanations, not a causal estimate of an LLM policy.",
        "",
        "## Held-out action matches",
        "",
        "| rule | mean assessment match | exact generator of every held-out trajectory? |",
        "|---|---:|---|",
    ]
    for rule, row in result["held_out_action_match"].items():
        lines.append(f"| `{rule}` | {row['mean_assessment_match_rate']:.4f} | {'yes' if row['cannot_exclude_as_exact_generator'] else 'no'} |")
    lines += [
        "",
        "The imitation-like rules (`match_if_equal_else_copy_rival`, `match_if_equal_else_undercut`) match 87.50% and 86.875% of held-out assessment actions, respectively, while own-price inertia matches 88.625% in the parent audit. None is an exact generator, so these are compatible descriptive baselines rather than identified mechanisms.",
        "",
        "## Initial-state counterfactuals",
        "",
        "| rule | equal starts preserved | unequal starts ending equal | unequal starts ending at floor | max updates |",
        "|---|---:|---:|---:|---:|",
    ]
    for rule, row in result["closed_loop_counterfactual"].items():
        lines.append(f"| `{rule}` | {row['equal_initials_preserved']}/{row['equal_initials']} | {row['unequal_initials_converge_to_equal']}/{100-row['equal_initials']} | {row['unequal_initials_converge_to_floor']}/{100-row['equal_initials']} | {row['max_updates_to_absorbing']} |")
    lines += [
        "",
        "The copying rule preserves every initial pair, including (6.0, 6.0), (6.5, 6.5), and (6.0, 6.5); it can therefore sustain high-price ties without strategic punishment. Match-if-equal-else-undercut preserves all ten equal-price starts (including high and mid prices) but drives most unequal starts to the floor. Myopic best response and mechanical undercutting drive every grid start to the floor. This demonstrates why the observed high-price absorbing states do not, by themselves, identify collusion or a strategic response.",
        "",
        "## Observed unequal-state transitions",
        "",
        f"- all transitions: `{result['observed_unequal_state_transitions']['all_rounds']}`",
        f"- assessment transitions: `{result['observed_unequal_state_transitions']['assessment_rounds']}`",
        "",
        "These conditional rates are descriptive and are not a substitute for the proposed feedback-surface experiment. They provide an offline audit of the copying/inertia alternative without adding paid model calls.",
        "",
        "## Reproduction",
        "",
        "```powershell",
        "python research/initial_state_baseline_sensitivity.py",
        "```",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("study", type=Path, nargs="?", default=DEFAULT_STUDY)
    parser.add_argument("out_dir", type=Path, nargs="?", default=Path("research/results/reviewer-revision-20261001/offline-initial-state-baselines"))
    args = parser.parse_args()
    result = analyze(args.study)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    (args.out_dir / "analysis.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    (args.out_dir / "report.md").write_text(render(result), encoding="utf-8")
    print(render(result))


if __name__ == "__main__":
    main()
