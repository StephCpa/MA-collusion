"""Offline-first runner for the AAMAS X1 best-response probe.

Default operation is a zero-call self-test. Paid execution requires an explicit
``--execute-paid`` flag, a new output directory, and a CNY cap. Requests are
sent sequentially with one ledger reservation per logical slot and no retry.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
import random
import ssl
import urllib.error
import urllib.request
from pathlib import Path
from statistics import mean
from typing import Any

import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from history_channel_requests import RequestLedger, StudyRequestFailure, error_diagnostic


MODEL = "deepseek-flash"
RETURNED_MODELS = {"deepseek-flash", "deepseek-v4.1-flash", "deepseek-v4-flash"}
TEMPERATURE = 0.3
MAX_TOKENS = 256
GRID = [2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5]
N_IDS = 48
N_DRAWS = 3
RESERVATION_MICRO_CNY = 20_000
SYSTEM_PROMPT = (
    "You are one seller in a two-seller market. Call choose_price exactly once. "
    "Return no prose and no second call."
)


def payoff(price: float, rival: float) -> float:
    """Current profit under the registered tie-split settlement rule."""
    demand = 100.0 * (10.0 - min(price, rival)) / 9.0
    if price < rival:
        quantity = demand
    elif price == rival:
        quantity = demand / 2.0
    else:
        quantity = 0.0
    return (price - 1.0) * quantity


def payoff_table() -> dict[str, list[float]]:
    return {str(r): [round(payoff(p, r), 6) for p in GRID] for r in (6.0, 6.5)}


def current_best_response(rival: float) -> float:
    vals = [payoff(p, rival) for p in GRID]
    best = max(vals)
    candidates = [p for p, v in zip(GRID, vals) if abs(v - best) < 1e-9]
    if len(candidates) != 1:
        raise AssertionError(f"Best response is not unique for rival={rival}: {candidates}")
    return candidates[0]


def horizon_sentence(horizon: str) -> str:
    if horizon == "terminal":
        return "This is the final decision. There are no future rounds; choose the price that maximizes current profit."
    if horizon == "continuing":
        return "This is a continuing interaction. Twenty-nine further rounds remain after this decision. Choose your current price as part of your strategy."
    raise ValueError(horizon)


def user_prompt(rival: float, horizon: str) -> str:
    table = payoff_table()
    rows = "\n".join(
        f"price={p:.2f}: if rival=6.00 profit={table['6.0'][i]:.3f}; if rival=6.50 profit={table['6.5'][i]:.3f}"
        for i, p in enumerate(GRID)
    )
    return (
        "You have marginal cost 1.00, reservation price 10.00, market size 100, and the allowed "
        "prices {2.00, 2.50, 3.00, 3.50, 4.00, 4.50, 5.00, 5.50, 6.00, 6.50}. Demand at market "
        "price p is 100*(10-p)/9. The lower-priced seller serves all demand; an exact tie splits "
        "demand equally. Your public price history is one row: own_price=6.50, "
        f"rival_price={rival:.2f}. The rival's current price is externally fixed at {rival:.2f} and "
        "cannot react to your current choice. Your current-profit table is:\n"
        f"{rows}\n{horizon_sentence(horizon)}\n"
        "Choose one allowed current price by calling choose_price exactly once."
    )


def function_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "properties": {"price": {"type": "number", "enum": GRID}},
        "required": ["price"],
    }


def build_manifest(schedule_seed: int = 20260930, namespace: str = "x1") -> dict[str, Any]:
    rng = random.Random(schedule_seed)
    slots: list[dict[str, Any]] = []
    for rival in (6.0, 6.5):
        for prompt_index in range(N_IDS):
            prompt_id = f"r{rival:.1f}-p{prompt_index:03d}"
            for horizon in ("terminal", "continuing"):
                for draw in range(N_DRAWS):
                    logical_id = f"{namespace}-{prompt_id}-{horizon[0]}{draw}"
                    body = {
                        "model": MODEL,
                        "messages": [
                            {"role": "system", "content": SYSTEM_PROMPT},
                            {"role": "user", "content": user_prompt(rival, horizon)},
                        ],
                        "tools": [
                            {
                                "type": "function",
                                "function": {
                                    "name": "choose_price",
                                    "parameters": function_schema(),
                                },
                            }
                        ],
                        "tool_choice": {"type": "function", "function": {"name": "choose_price"}},
                        "temperature": TEMPERATURE,
                        "max_tokens": MAX_TOKENS,
                        "thinking": {"type": "disabled"},
                        "stream": False,
                    }
                    slots.append(
                        {
                            "logical_id": logical_id,
                            "prompt_id": prompt_id,
                            "rival_price": rival,
                            "horizon": horizon,
                            "draw": draw,
                            "request": body,
                        }
                    )
    rng.shuffle(slots)
    for index, slot in enumerate(slots):
        slot["schedule_index"] = index
    return {
        "protocol": "aamas2027-x1-best-response-v0.1",
        "schedule_seed": schedule_seed,
        "logical_id_namespace": namespace,
        "model_requested": MODEL,
        "allowed_returned_models": sorted(RETURNED_MODELS),
        "temperature": TEMPERATURE,
        "max_tokens": MAX_TOKENS,
        "thinking": {"type": "disabled"},
        "planned_calls": len(slots),
        "rival_prices": [6.0, 6.5],
        "horizons": ["terminal", "continuing"],
        "prompt_ids_per_rival": N_IDS,
        "draws_per_cell": N_DRAWS,
        "payoff_table": payoff_table(),
        "slots": slots,
    }


def validate_manifest(manifest: dict[str, Any]) -> None:
    slots = manifest["slots"]
    assert len(slots) == 2 * 2 * N_IDS * N_DRAWS
    assert len({s["logical_id"] for s in slots}) == len(slots)
    assert {s["rival_price"] for s in slots} == {6.0, 6.5}
    assert {s["horizon"] for s in slots} == {"terminal", "continuing"}
    for rival in (6.0, 6.5):
        assert sum(s["rival_price"] == rival for s in slots) == 2 * N_IDS * N_DRAWS
        assert current_best_response(rival) == 5.5
    for s in slots:
        body = s["request"]
        assert body["model"] == MODEL
        assert body["temperature"] == TEMPERATURE
        assert body["max_tokens"] == MAX_TOKENS
        assert body["thinking"] == {"type": "disabled"}
        assert body["tool_choice"]["function"]["name"] == "choose_price"
        assert body["tools"][0]["function"]["parameters"] == function_schema()
        prompt = body["messages"][1]["content"]
        assert f"rival_price={s['rival_price']:.2f}" in prompt
        assert "sales" not in prompt.lower() and "welfare" not in prompt.lower()


def mock_payload(price: float, model: str = MODEL) -> dict[str, Any]:
    return {
        "id": "mock",
        "model": model,
        "system_fingerprint": "mock-fingerprint",
        "usage": {"prompt_tokens": 100, "completion_tokens": 12},
        "choices": [
            {
                "finish_reason": "tool_calls",
                "message": {
                    "content": None,
                    "tool_calls": [
                        {
                            "function": {
                                "name": "choose_price",
                                "arguments": json.dumps({"price": price}),
                            }
                        }
                    ],
                },
            }
        ],
    }


def parse_payload(payload: dict[str, Any]) -> float:
    if payload.get("model") not in RETURNED_MODELS:
        raise StudyRequestFailure("Returned model mismatch")
    try:
        choices = payload["choices"]
        if len(choices) != 1 or choices[0].get("finish_reason") != "tool_calls":
            raise ValueError
        message = choices[0]["message"]
        calls = message["tool_calls"]
        if len(calls) != 1 or message.get("content") not in (None, ""):
            raise ValueError
        fn = calls[0]["function"]
        if fn["name"] != "choose_price":
            raise ValueError
        args = json.loads(fn["arguments"])
        price = args["price"]
        if type(price) not in (int, float) or not math.isfinite(float(price)):
            raise ValueError
        price = float(price)
        if not any(abs(price - p) < 1e-9 for p in GRID):
            raise ValueError
        return price
    except (KeyError, IndexError, TypeError, ValueError, json.JSONDecodeError):
        raise StudyRequestFailure("Invalid forced-function delivery") from None


def wilson(successes: int, total: int, z: float = 1.959963984540054) -> list[float]:
    if total <= 0:
        return [None, None]  # type: ignore[return-value]
    phat = successes / total
    denom = 1 + z * z / total
    centre = (phat + z * z / (2 * total)) / denom
    half = z * math.sqrt(phat * (1 - phat) / total + z * z / (4 * total * total)) / denom
    return [centre - half, centre + half]


def _cluster_values(rows: list[dict[str, Any]], rival: float, horizon: str, outcome: str) -> list[float]:
    selected = [r for r in rows if r["rival_price"] == rival and r["horizon"] == horizon]
    by_id: dict[str, list[float]] = {}
    for row in selected:
        by_id.setdefault(row["prompt_id"], []).append(1.0 if outcome(row["price"], rival) else 0.0)
    if any(len(v) != N_DRAWS for v in by_id.values()) or len(by_id) != N_IDS:
        raise ValueError("Incomplete X1 cluster")
    return [mean(v) for _, v in sorted(by_id.items())]


def _bootstrap_gap(rows: list[dict[str, Any]], rival: float, outcome, seed: int = 991) -> list[float]:
    terminal = _cluster_values(rows, rival, "terminal", outcome)
    continuing = _cluster_values(rows, rival, "continuing", outcome)
    rng = random.Random(seed + int(rival * 10))
    values = []
    for _ in range(10_000):
        idx = [rng.randrange(N_IDS) for _ in range(N_IDS)]
        values.append(mean(terminal[i] - continuing[i] for i in idx))
    values.sort()
    return [values[250], values[9749]]


def analyze(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if len(rows) != 2 * 2 * N_IDS * N_DRAWS:
        raise ValueError("Fixed X1 denominator violated")

    def br(price: float, _rival: float) -> bool:
        return abs(price - 5.5) < 1e-9

    def match(price: float, rival: float) -> bool:
        return abs(price - rival) < 1e-9

    cells: dict[str, Any] = {}
    br_gaps = []
    match_gaps = []
    cluster_cache = {}
    for rival in (6.0, 6.5):
        t_br = _cluster_values(rows, rival, "terminal", br)
        c_br = _cluster_values(rows, rival, "continuing", br)
        t_match = _cluster_values(rows, rival, "terminal", match)
        c_match = _cluster_values(rows, rival, "continuing", match)
        cluster_cache[rival] = (t_br, c_br, t_match, c_match)
        terminal_draws = [r for r in rows if r["rival_price"] == rival and r["horizon"] == "terminal"]
        successes = sum(br(r["price"], rival) for r in terminal_draws)
        cell_br_gap = mean(t_br) - mean(c_br)
        cell_match_gap = mean(c_match) - mean(t_match)
        br_gaps.append(cell_br_gap)
        match_gaps.append(cell_match_gap)
        cells[str(rival)] = {
            "terminal_br": mean(t_br),
            "continuing_br": mean(c_br),
            "br_gap": cell_br_gap,
            "br_gap_ci": _bootstrap_gap(rows, rival, br),
            "terminal_match": mean(t_match),
            "continuing_match": mean(c_match),
            "forbearance_gap": cell_match_gap,
            "terminal_br_wilson_ci": wilson(successes, len(terminal_draws)),
            "terminal_draws": len(terminal_draws),
        }
    pooled_rng = random.Random(7749)
    pooled_br_boot = []
    pooled_match_boot = []
    for _ in range(10_000):
        br_terms = []
        br_matches = []
        for rival in (6.0, 6.5):
            t_br, c_br, t_match, c_match = cluster_cache[rival]
            idx = [pooled_rng.randrange(N_IDS) for _ in range(N_IDS)]
            br_terms.append(mean(t_br[i] - c_br[i] for i in idx))
            br_matches.append(mean(c_match[i] - t_match[i] for i in idx))
        pooled_br_boot.append(mean(br_terms))
        pooled_match_boot.append(mean(br_matches))
    pooled_br_boot.sort()
    pooled_match_boot.sort()
    pooled_br_ci = [pooled_br_boot[250], pooled_br_boot[9749]]
    pooled_match_ci = [pooled_match_boot[250], pooled_match_boot[9749]]
    pooled_br_gap = mean(br_gaps)
    pooled_match_gap = mean(match_gaps)
    competence_pass = all(
        cells[str(r)]["terminal_br"] >= 0.80
        and cells[str(r)]["terminal_br_wilson_ci"][0] >= 0.70
        for r in (6.0, 6.5)
    )
    horizon_pass = (
        competence_pass
        and pooled_br_gap >= 0.20
        and pooled_br_ci[0] > 0
        and pooled_match_ci[0] > 0
    )
    return {
        "protocol": "aamas2027-x1-best-response-v0.1",
        "planned_calls": len(rows),
        "usable_calls": len(rows),
        "cells": cells,
        "pooled_br_gap": pooled_br_gap,
        "pooled_br_gap_ci": pooled_br_ci,
        "pooled_forbearance_gap": pooled_match_gap,
        "pooled_forbearance_gap_ci": pooled_match_ci,
        "interpretation_gate": {
            "competence_pass": competence_pass,
            "horizon_sensitive_costly_matching": horizon_pass,
            "note": "Continuing departures are interpreted only after the competence gate passes.",
        },
    }


def mock_rows(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    """Deterministic positive-control mock: terminal BR, continuing matching."""
    rows = []
    for slot in manifest["slots"]:
        rival = slot["rival_price"]
        price = 5.5 if slot["horizon"] == "terminal" else rival
        rows.append(
            {
                "logical_id": slot["logical_id"],
                "prompt_id": slot["prompt_id"],
                "rival_price": rival,
                "horizon": slot["horizon"],
                "draw": slot["draw"],
                "price": price,
                "model_returned": "mock",
            }
        )
    return rows


class HTTPSender:
    def __init__(self, api_key: str, timeout: float = 60.0):
        if not api_key or any(c.isspace() for c in api_key):
            raise ValueError("Missing or malformed DEEPSEEK_API_KEY")
        self.api_key = api_key
        self.timeout = timeout
        # The desktop proxy accepts ordinary web traffic but stalls on the
        # DeepSeek completion endpoint.  Use a direct opener for this explicit
        # API host; no credentials are sent to an intermediary proxy.
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())

    def __call__(self, body: dict[str, Any]) -> dict[str, Any]:
        if body.get("model") != MODEL or body.get("thinking") != {"type": "disabled"}:
            raise StudyRequestFailure("Unexpected request policy")
        req = urllib.request.Request(
            "https://api.deepseek.com/chat/completions",
            data=json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
            method="POST",
            headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"},
        )
        with self.opener.open(req, timeout=self.timeout) as response:
            return json.loads(response.read().decode("utf-8"))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    """Never carry the bearer credential across an HTTP redirect."""

    def redirect_request(self, *args, **kwargs):
        return None


def peak_cost(prompt_tokens: int, completion_tokens: int) -> int:
    return 2 * prompt_tokens + 8 * completion_tokens


def audited_call(ledger: RequestLedger, slot: dict[str, Any], sender, output: Path) -> dict[str, Any]:
    logical_id = slot["logical_id"]
    # Reserve before opening the network connection.  If the provider times out,
    # the request remains a charged/unknown exposure and the logical id can never
    # be retried.
    ledger.reserve(logical_id, RESERVATION_MICRO_CNY)
    audit = output / "audit" / logical_id
    audit.mkdir(parents=True, exist_ok=False)
    body = copy.deepcopy(slot["request"])
    (audit / "request.json").write_text(json.dumps(body, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        payload = sender(body)
        (audit / "response.json").write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    except Exception as exc:
        diagnostic = error_diagnostic(exc)
        (audit / "failure.json").write_text(json.dumps({"error_type": type(exc).__name__, "diagnostic": diagnostic}), encoding="utf-8")
        ledger.finish(
            logical_id,
            "transport_unknown",
            stop=True,
            error_type=type(exc).__name__,
            diagnostic=diagnostic,
        )
        raise StudyRequestFailure("Transport failed; reservation retained") from exc
    usage = payload.get("usage", {})
    prompt_tokens = usage.get("prompt_tokens")
    completion_tokens = usage.get("completion_tokens")
    if type(prompt_tokens) is not int or type(completion_tokens) is not int:
        ledger.finish(logical_id, "usage_unknown", stop=True)
        raise StudyRequestFailure("Usage unknown; study halted")
    charge = peak_cost(prompt_tokens, completion_tokens)
    try:
        price = parse_payload(payload)
    except StudyRequestFailure as exc:
        ledger.finish(
            logical_id,
            "invalid_delivery",
            charge=charge,
            stop=True,
            error_type=type(exc).__name__,
            usage={"prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens},
        )
        raise
    ledger.finish(
        logical_id,
        "delivered",
        charge=charge,
        usage={"prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens},
        price=price,
    )
    return {
        "logical_id": logical_id,
        "prompt_id": slot["prompt_id"],
        "rival_price": slot["rival_price"],
        "horizon": slot["horizon"],
        "draw": slot["draw"],
        "price": price,
        "model_returned": payload.get("model"),
        "system_fingerprint": payload.get("system_fingerprint"),
        "usage": {"prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens},
        "response_id": payload.get("id"),
    }


def run_paid(output: Path, cap_cny: int, schedule_seed: int, namespace: str) -> dict[str, Any]:
    if output.exists():
        raise ValueError("Output directory already exists")
    output.mkdir(parents=True)
    manifest = build_manifest(schedule_seed=schedule_seed, namespace=namespace)
    validate_manifest(manifest)
    (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    ledger = RequestLedger(output / "requests.jsonl", cap_cny * 1_000_000)
    sender = HTTPSender(os.environ.get("DEEPSEEK_API_KEY", ""))
    rows: list[dict[str, Any]] = []
    for slot in manifest["slots"]:
        row = audited_call(ledger, slot, sender, output)
        rows.append(row)
        (output / "rows.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    report = analyze(rows)
    report["accounted_or_reserved_cny"] = ledger.exposure() / 1_000_000
    report["model_returned"] = sorted({r["model_returned"] for r in rows})
    report["system_fingerprints"] = sorted({r["system_fingerprint"] for r in rows})
    (output / "analysis.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def selftest() -> dict[str, Any]:
    manifest = build_manifest()
    validate_manifest(manifest)
    assert current_best_response(6.0) == 5.5
    assert current_best_response(6.5) == 5.5
    rows = mock_rows(manifest)
    report = analyze(rows)
    assert report["interpretation_gate"]["competence_pass"]
    assert report["pooled_br_gap"] == 1.0
    assert report["pooled_forbearance_gap"] == 1.0
    return {"passed": True, "planned_calls": len(manifest["slots"]), "mock_report": report}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--offline-selftest", action="store_true")
    parser.add_argument("--write-mock", type=Path)
    parser.add_argument("--execute-paid", action="store_true")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--cap-cny", type=int)
    parser.add_argument("--schedule-seed", type=int, default=2026093001)
    parser.add_argument("--namespace", default="x1-replacement-20260930")
    args = parser.parse_args()
    if args.offline_selftest or not args.execute_paid:
        result = selftest()
        if args.write_mock:
            if args.write_mock.exists():
                raise SystemExit("mock output exists")
            args.write_mock.mkdir(parents=True)
            manifest = build_manifest()
            validate_manifest(manifest)
            (args.write_mock / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
            (args.write_mock / "rows.json").write_text(json.dumps(mock_rows(manifest), ensure_ascii=False, indent=2), encoding="utf-8")
            report = analyze(mock_rows(manifest))
            (args.write_mock / "analysis.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
            result["mock_output"] = str(args.write_mock)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    if args.output is None or args.cap_cny is None or args.cap_cny <= 0:
        parser.error("Paid execution requires a new --output and positive --cap-cny")
    report = run_paid(args.output, args.cap_cny, args.schedule_seed, args.namespace)
    print(json.dumps({"completed": report["usable_calls"], "cap_cny": args.cap_cny, "accounted_or_reserved_cny": report["accounted_or_reserved_cny"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
