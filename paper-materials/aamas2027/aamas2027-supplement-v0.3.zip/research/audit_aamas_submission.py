"""Offline pre-submission audit for the AAMAS staging manuscript and ZIP."""

from __future__ import annotations

import re
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TEX = ROOT / "papers" / "aamas2027" / "history-display-observability.tex"
BIB = ROOT / "papers" / "aamas2027" / "history-display-observability.bib"
LOG = ROOT / "papers" / "aamas2027" / "build" / "history-display-observability.log"
PDF = ROOT / "papers" / "aamas2027" / "build" / "history-display-observability.pdf"
SUPP = ROOT / "papers" / "aamas2027" / "aamas2027-supplement-v0.1.zip"


def audit() -> dict:
    tex = TEX.read_text(encoding="utf-8")
    bib = BIB.read_text(encoding="utf-8")
    log = LOG.read_text(encoding="utf-8") if LOG.exists() else ""
    cited = {key.strip() for group in re.findall(r"\\cite\{([^}]+)\}", tex) for key in group.split(",")}
    bib_keys = set(re.findall(r"^@\w+\{([^,]+),", bib, flags=re.MULTILINE))
    abstract_match = re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", tex, flags=re.S)
    abstract_words = len(re.findall(r"\b[\w'-]+\b", abstract_match.group(1))) if abstract_match else 0
    source_checks = {
        "anonymous_marker": "anonymous" in tex.lower(),
        "no_api_key_literal": not re.search(r"sk-[A-Za-z0-9]{20,}", tex),
        "no_private_path": not re.search(r"(?:C:|/home/|/Users/)", tex),
        "all_citations_resolve": cited <= bib_keys,
        "abstract_100_300_words": 100 <= abstract_words <= 300,
        "required_sections": all(marker in tex for marker in ("\\section{Introduction}", "\\section{Results}", "\\section{Discussion}", "\\section{Conclusion}")),
        "no_undefined_citations": "undefined citations" not in log.lower() and "undefined references" not in log.lower(),
        "no_overfull_hbox": "Overfull \\hbox" not in log,
    }
    pdf_pages = None
    if PDF.exists():
        import subprocess

        info = subprocess.check_output(["pdfinfo", str(PDF)], text=True, errors="replace")
        match = re.search(r"^Pages:\s+(\d+)", info, flags=re.MULTILINE)
        pdf_pages = int(match.group(1)) if match else None
    source_checks["staging_pdf_at_most_8_pages"] = pdf_pages is not None and pdf_pages <= 8
    zip_bytes = SUPP.stat().st_size if SUPP.exists() else None
    source_checks["supplement_under_25mb"] = zip_bytes is not None and zip_bytes <= 25 * 1024 * 1024
    source_checks["supplement_no_local_or_key_pattern"] = False
    if SUPP.exists():
        with zipfile.ZipFile(SUPP) as archive:
            blob = b"\n".join(archive.read(name) for name in archive.namelist())
        source_checks["supplement_no_local_or_key_pattern"] = not re.search(
            rb"C:\\\\(Users|work)|sk-[A-Za-z0-9]{20,}", blob
        )
    return {
        "passed": all(source_checks.values()),
        "checks": source_checks,
        "citation_count": len(cited),
        "abstract_words": abstract_words,
        "pdf_pages": pdf_pages,
        "supplement_bytes": zip_bytes,
    }


if __name__ == "__main__":
    import argparse
    import json

    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = audit()
    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    raise SystemExit(0 if result["passed"] else 1)
