"""Offline statistical qualification for the frozen X1 and X2 results.

This module does not refit either registered estimand and never calls a model.
It validates the denominators used in the manuscript-facing qualification,
computes one-sided zero-event binomial upper bounds, and exposes the controlled-
initial completion ranges already emitted by the structure audit.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
X1 = ROOT / "research/results/aamas2027-supplement-candidate-20260930/x1-live-replacement-20260930T0628+0800/analysis.json"
X2 = ROOT / "research/results/aamas2027-supplement-candidate-20260930/x2-live-20260930T0638+0800/analysis.json"
STRUCTURE = ROOT / "research/results/controlled-initial-structure-audit-20260927/audit.json"


def zero_event_upper(n: int, alpha: float = 0.05) -> float:
    """One-sided 1-alpha binomial upper bound after observing zero events."""
    if n <= 0:
        raise ValueError("n must be positive")
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie in (0, 1)")
    return 1.0 - alpha ** (1.0 / n)


def qualify(x1: dict[str, Any], x2: dict[str, Any], structure: dict[str, Any]) -> dict[str, Any]:
    """Validate frozen counts and return reproducible qualification values."""
    if x1["planned_calls"] != 576 or x1["usable_calls"] != 576:
        raise AssertionError("X1 planned/usable denominator drift")
    for cell in ("6.0", "6.5"):
        row = x1["cells"][cell]
        if row["terminal_draws"] != 144:
            raise AssertionError(f"X1 terminal denominator drift in {cell}")
    if x2["planned_trajectories"] != 192 or x2["completed_trajectories"] != 192:
        raise AssertionError("X2 trajectory denominator drift")
    if x2["complete_blocks"] != 48:
        raise AssertionError("X2 block denominator drift")
    if x2["cut5_interaction"] != 0 or x2["non_accommodating_interaction"] != 0:
        raise AssertionError("X2 interaction changed; review qualification")
    primary = structure["full_analysis"]["primary"]
    return {
        "x1": {
            "terminal_draws_per_cell": 144,
            "zero_matching_upper_95_if_independent": zero_event_upper(144),
            "terminal_cluster_count_per_cell": 48,
            "terminal_cluster_wilson_lower_reference": 0.9258998703338824,
            "pooled_br_gap": x1["pooled_br_gap"],
            "pooled_br_gap_ci": x1["pooled_br_gap_ci"],
            "pooled_forbearance_gap": x1["pooled_forbearance_gap"],
            "pooled_forbearance_gap_ci": x1["pooled_forbearance_gap_ci"],
            "terminal_wilson_lower": {
                cell: x1["cells"][cell]["terminal_br_wilson_ci"][0]
                for cell in ("6.0", "6.5")
            },
        },
        "x2": {
            "complete_blocks": 48,
            "zero_event_upper_95_if_independent": zero_event_upper(48),
            "cut5_interaction": x2["cut5_interaction"],
            "cut5_interaction_ci": x2["cut5_interaction_ci"],
            "non_accommodating_interaction": x2["non_accommodating_interaction"],
            "non_accommodating_interaction_ci": x2["non_accommodating_interaction_ci"],
            "delayed_all_accommodating_cp_lower_95_two_sided": 0.025 ** (1.0 / 48),
        },
        "controlled_initial": {
            "D_asym": {
                "complete_blocks": primary["D_asym"]["complete_blocks"],
                "estimate": primary["D_asym"]["mean"],
                "planned_completion_range": primary["D_asym"]["planned_completion_range"],
            },
            "J": {
                "complete_blocks": primary["J"]["complete_blocks"],
                "estimate": primary["J"]["mean"],
                "planned_completion_range": primary["J"]["planned_completion_range"],
            },
            "failed_cells": [
                "LL-natural block 37",
                "LL-natural block 41",
                "HH-hide_rival block 37",
                "LH-hide_rival block 47",
            ],
        },
        "interpretation": {
            "zero_width_bootstrap": "Degenerate resampling support, not proof of an exact population zero.",
            "independent_zero_event_bound": "Calibration only; it does not replace the cluster/block estimand.",
            "completion_range": "Missing-outcome bounds, not confidence intervals or imputation.",
        },
    }


def load() -> dict[str, Any]:
    # One archived X1 export ended with the two literal characters ``\\n``
    # after the JSON object. Strip that transport artifact without mutating
    # the frozen evidence file.
    def read_json(path: Path) -> dict[str, Any]:
        text = path.read_text(encoding="utf-8").rstrip()
        if text.endswith(r"\n"):
            text = text[:-2].rstrip()
        return json.loads(text)

    return qualify(
        read_json(X1),
        read_json(X2),
        read_json(STRUCTURE),
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    result = load()
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
