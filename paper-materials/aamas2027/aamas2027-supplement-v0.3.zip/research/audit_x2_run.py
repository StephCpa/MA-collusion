"""Audit a completed X2 run without refitting its behavioral estimand."""
from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path


def audit(run: Path) -> dict:
    rows = json.loads((run / "rows.json").read_text(encoding="utf-8"))
    plan = json.loads((run / "plan.json").read_text(encoding="utf-8"))
    ledger = [json.loads(line) for line in (run / "requests.jsonl").read_text(encoding="utf-8").splitlines()]
    errors = []
    if len(rows) != 192:
        errors.append(f"trajectory_count={len(rows)}")
    if any(r.get("status") != "completed" or len(r.get("events", [])) != 30 for r in rows):
        errors.append("incomplete_trajectory")
    by_block = {}
    for row in rows:
        by_block.setdefault(row["block"], {})[row["condition"]] = row
    if len(by_block) != 48 or any(set(cells) != {"N0", "N1", "H0", "H1"} for cells in by_block.values()):
        errors.append("incomplete_four_arm_block")
    forced_blocks = Counter(row["forced_seller"] for row in rows if row["condition"] in {"N1", "H1"})
    if forced_blocks != Counter({"seller_a": 48, "seller_b": 48}):
        errors.append(f"forced_seller_imbalance={dict(forced_blocks)}")

    forced_events = 0
    forced_exact = 0
    unexpected_forced = 0
    shadow_mismatches = 0
    request_calls = 0
    models = Counter()
    fingerprints = Counter()
    prompt_surface = Counter()
    invalid_nonforced = 0
    for row in rows:
        force_arm = row["condition"] in {"N1", "H1"}
        event10 = next(e for e in row["events"] if e["round"] == 10)
        for seller in ("seller_a", "seller_b"):
            is_forced = bool(event10["forced"][seller])
            expected_forced = force_arm and seller == row["forced_seller"]
            if is_forced:
                forced_events += 1
                if float(event10["prices"][seller]) == 5.5:
                    forced_exact += 1
            if is_forced != expected_forced:
                unexpected_forced += 1
            if float(event10["requested_prices"][seller]) != float(event10["prices"][seller]):
                if not expected_forced:
                    shadow_mismatches += 1
            elif expected_forced:
                # A forced action is expected to be different from the shadow in
                # this audit; equality is retained as a warning, not a failure.
                pass
            for event in row["events"]:
                meta = event.get("model_calls", {}).get(seller)
                if meta:
                    request_calls += 1
                    models[meta.get("model_returned")] += 1
                    fingerprints[meta.get("system_fingerprint")] += 1
        if row["condition"].startswith("H"):
            prompt_surface["hidden_arm"] += 1
        else:
            prompt_surface["natural_arm"] += 1

    # Audit the actual saved request payloads, not only the runner's arm label.
    request_files = list((run / "audit").rglob("request.json"))
    hidden_bad = natural_bad = forbidden_fields = 0
    expected_keys = {
        "allowed_prices", "complete_public_price_history", "constraint",
        "current_public_notices", "decisions_remaining_including_current",
        "demand_rule", "marginal_cost", "market_size", "public_notice_history",
        "reservation_price", "round", "total_rounds",
    }
    for request_file in request_files:
        envelope = json.loads(request_file.read_text(encoding="utf-8"))
        body = envelope["body"]
        data = json.loads(body["messages"][1]["content"])
        if set(data) != expected_keys:
            forbidden_fields += 1
        hidden = bool(re.search(r"-(H[01])-", request_file.parent.name))
        history = data["complete_public_price_history"]
        rivals = [row["rival_price"] for row in history]
        if hidden and any(value is not None for value in rivals):
            hidden_bad += 1
        if not hidden and any(value is None for value in rivals):
            natural_bad += 1
    if len(request_files) != 7680:
        errors.append(f"request_file_count={len(request_files)}")
    if hidden_bad or natural_bad or forbidden_fields:
        errors.append(f"prompt_surface_bad=hidden:{hidden_bad},natural:{natural_bad},keys:{forbidden_fields}")

    finished = [x for x in ledger if x.get("event") == "finished"]
    reserved = {x.get("request_id") for x in ledger if x.get("event") == "reserved"}
    finished_ids = {x.get("request_id") for x in ledger if x.get("event") == "finished"}
    pending = reserved - finished_ids
    if pending:
        errors.append(f"pending_ledger_rows={len(pending)}")
    if len(finished) != 7680:
        errors.append(f"finished_request_count={len(finished)}")
    if any(x.get("status") != "delivered" for x in finished):
        errors.append("non_delivered_request")
    return {
        "passed": not errors,
        "errors": errors,
        "trajectory_count": len(rows),
        "complete_blocks": len(by_block),
        "forced_round10_events": forced_events,
        "forced_round10_exact_5_5": forced_exact,
        "unexpected_forced_flags": unexpected_forced,
        "shadow_mismatches_nonforced": shadow_mismatches,
        "model_call_metadata_count": request_calls,
        "finished_requests": len(finished),
        "pending_requests": len(pending),
        "model_returned": dict(models),
        "system_fingerprints": dict(fingerprints),
        "ledger_charge_micro_cny": sum(x.get("charge") or 0 for x in finished),
        "prompt_surface_trajectory_counts": dict(prompt_surface),
        "request_file_count": len(request_files),
        "hidden_prompt_rival_leaks": hidden_bad,
        "natural_prompt_rival_missing": natural_bad,
        "prompt_key_schema_violations": forbidden_fields,
        "plan_protocol": plan.get("protocol"),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("run", type=Path)
    args = parser.parse_args()
    result = audit(args.run)
    (args.run / "audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
