"""Injected-sender request gate: no credentials, network client or paid CLI.

Single-process, thread-safe ledger. Money is integer micro-CNY supplied by a
future verified pricing adapter. Reservations are only as conservative as the
caller-provided envelope; this module cannot guarantee a provider invoice cap.
"""
import copy
import errno
import http.client
import json
import math
import os
import socket
import ssl
import threading
import urllib.error
from pathlib import Path

from history_channel_study import RecoverableArmFailure


class ArmRequestFailure(RecoverableArmFailure):
    pass


class StudyRequestFailure(RuntimeError):
    pass


def error_diagnostic(error):
    """Conservative classification without persisting exception text or URLs.

    URLError.reason is an exception link, not __cause__. Unknown leaves and
    wrapper types fail closed. A known transient failure ends the arm, never
    retries the request. Any fatal node takes precedence over transient nodes.
    """
    pending=[error]; seen=set(); nodes=[]; fatal=False; transient=False
    codes={errno.ETIMEDOUT, errno.ECONNRESET, errno.ECONNABORTED, errno.EPIPE,
           10053, 10054, 10060}
    while pending:
        exc=pending.pop()
        if not isinstance(exc,BaseException) or id(exc) in seen:
            continue
        seen.add(id(exc))
        links=[getattr(exc,'__cause__',None)]
        if isinstance(exc,urllib.error.URLError):
            links.append(exc.reason)
        links=[item for item in links if isinstance(item,BaseException)]
        pending.extend(links)
        node={'type':type(exc).__name__}
        for source,target in [('errno','errno'),('winerror','winerror'),
                              ('verify_code','verify_code')]:
            # HTTPError delegates missing attributes to a file wrapper; bypass
            # that delegation when collecting optional diagnostic fields.
            try: value=object.__getattribute__(exc,source)
            except AttributeError: value=None
            if type(value) is int: node[target]=value
        if isinstance(exc,urllib.error.HTTPError):
            node['category']='http_error'
            if type(exc.code) is int: node['http_status']=exc.code
            fatal=True
        elif isinstance(exc,ssl.SSLError):
            node['category']='tls_error'; fatal=True
        elif isinstance(exc,socket.gaierror):
            recoverable=exc.errno==socket.EAI_AGAIN
            node['category']='temporary_dns' if recoverable else 'dns_error'
            transient |= recoverable; fatal |= not recoverable
        elif isinstance(exc,(TimeoutError,socket.timeout,ConnectionResetError,ConnectionAbortedError,
                             BrokenPipeError,http.client.RemoteDisconnected)) or (
                isinstance(exc,OSError) and
                (getattr(exc,'errno',None) in codes or getattr(exc,'winerror',None) in codes)):
            node['category']='transient_transport'; transient=True
        elif type(exc) is urllib.error.URLError and links:
            node['category']='transport_wrapper'
        else:
            node['category']='unknown'; fatal=True
        nodes.append(node)
    return {'classification':'arm_failure' if transient and not fatal else 'study_stop',
            'chain':nodes}


def classify(error):
    return error_diagnostic(error)['classification']


def money(value):
    if type(value) is not int or value<0:
        raise ValueError('Money must be a nonnegative integer in micro-CNY')
    return value


class RequestLedger:
    def __init__(self,path,cap_micro_cny):
        self.path=Path(path)
        self.cap=money(cap_micro_cny)
        self.lock=threading.RLock()
        self.rows={}
        self.halted=False
        self.path.parent.mkdir(parents=True,exist_ok=True)
        # Refuse reopening: uncertain pending calls must never be redispatched.
        with self.path.open('x',encoding='utf-8') as f:
            f.write(json.dumps({'event':'opened','cap_micro_cny':self.cap})+'\n')
            f.flush(); os.fsync(f.fileno())

    def append(self,event):
        try:
            with self.path.open('a',encoding='utf-8') as f:
                f.write(json.dumps(event,sort_keys=True)+'\n')
                f.flush(); os.fsync(f.fileno())
        except BaseException:
            self.halted=True
            raise

    def exposure(self):
        return sum(r['charge'] if r['charge'] is not None else r['reserved'] for r in self.rows.values())

    def reserve(self,request_id,envelope):
        envelope=money(envelope)
        if envelope==0: raise ValueError('A request needs a positive reservation')
        with self.lock:
            if self.halted or request_id in self.rows:
                raise StudyRequestFailure('Halted or duplicate logical request')
            if self.exposure()+envelope>self.cap:
                self.halted=True
                self.append({'event':'halt','reason':'budget_unavailable'})
                raise StudyRequestFailure('Budget unavailable')
            row={'request_id':request_id,'status':'pending','reserved':envelope,'charge':None}
            self.append({'event':'reserved',**row})
            self.rows[request_id]=row

    def finish(self,request_id,status,charge=None,stop=False,error_type=None,usage=None,price=None,diagnostic=None):
        with self.lock:
            row=self.rows[request_id]
            if row['status']!='pending': raise StudyRequestFailure('Already terminal')
            if charge is not None: money(charge)
            over=charge is not None and charge>row['reserved']
            self.halted |= stop or over
            updated={**row,'status':status,'charge':charge,'usage':usage,'price':price}
            self.append({'event':'finished',**updated,'halted':self.halted,
                         'envelope_exceeded':over,'error_type':error_type,
                         'diagnostic':diagnostic})
            self.rows[request_id]=updated
            if over: raise StudyRequestFailure('Actual cost exceeded envelope; recorded, study halted')


def parse_price(payload,expected_model,allowed):
    if payload.get('model')!=expected_model:
        raise StudyRequestFailure('Returned model mismatch')
    try:
        choices=payload['choices']
        if len(choices)!=1: raise ValueError()
        message=choices[0]['message']; calls=message['tool_calls']
        if choices[0].get('finish_reason')!='tool_calls' or len(calls)!=1 or message.get('content') not in (None,''):
            raise ValueError()
        function=calls[0]['function']
        if function['name']!='choose_price': raise ValueError()
        args=json.loads(function['arguments'])
        if not isinstance(args,dict) or set(args)!={'price'}: raise ValueError()
        price=args['price']
        if type(price) not in (int,float) or not math.isfinite(price) or price not in allowed:
            raise ValueError()
        return price
    except (KeyError,IndexError,TypeError,ValueError):
        raise ArmRequestFailure('Invalid price delivery') from None


def dispatch_once(ledger,request_id,body,envelope,sender,cost_fn):
    """sender(body)->raw response, cost_fn(prompt_tokens,completion_tokens)->micro-CNY.

No retry. A missing/invalid usage bill keeps the full reservation and halts.
In-flight requests may finish after another thread halts future dispatch.
"""
    ledger.reserve(request_id,envelope)
    try:
        payload=sender(copy.deepcopy(body))
    except Exception as exc:
        diagnostic=error_diagnostic(exc)
        stop=diagnostic['classification']=='study_stop'
        ledger.finish(request_id,'transport_unknown',stop=stop,error_type=type(exc).__name__,
                      diagnostic=diagnostic)
        error=StudyRequestFailure if stop else ArmRequestFailure
        raise error('Transport failed; reservation retained') from exc
    charge=None
    try:
        usage=payload['usage']
        prompt,completion=usage['prompt_tokens'],usage['completion_tokens']
        if type(prompt) is not int or type(completion) is not int or min(prompt,completion)<0:
            raise ValueError()
        charge=money(cost_fn(prompt,completion))
    except Exception:
        ledger.finish(request_id,'usage_unknown',stop=True)
        raise StudyRequestFailure('Usage unknown; reservation retained') from None
    try:
        allowed=body['tools'][0]['function']['parameters']['properties']['price']['enum']
        price=parse_price(payload,body['model'],allowed)
    except (ArmRequestFailure,StudyRequestFailure) as exc:
        stop=isinstance(exc,StudyRequestFailure)
        ledger.finish(request_id,'invalid_delivery',charge,stop,type(exc).__name__,
                      usage={'prompt_tokens':prompt,'completion_tokens':completion})
        raise
    except Exception as exc:
        ledger.finish(request_id,'unexpected_validation_error',charge,True,type(exc).__name__,
                      usage={'prompt_tokens':prompt,'completion_tokens':completion})
        raise StudyRequestFailure('Unexpected validation error') from exc
    ledger.finish(request_id,'delivered',charge,usage={'prompt_tokens':prompt,'completion_tokens':completion},price=price)
    return price
