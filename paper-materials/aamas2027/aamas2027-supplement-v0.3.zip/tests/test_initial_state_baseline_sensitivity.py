import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "research"))
from initial_state_baseline_sensitivity import DEFAULT_STUDY, analyze


@pytest.fixture(scope="module")
def result():
    return analyze(DEFAULT_STUDY)


def test_analysis_is_offline_and_covers_full_initial_grid(result):
    assert result["network_calls"] == 0
    assert all(row["grid_initials"] == 100 for row in result["closed_loop_counterfactual"].values())


def test_copying_preserves_high_and_mid_equal_starts(result):
    row = result["closed_loop_counterfactual"]["match_if_equal_else_copy_rival"]
    assert row["equal_initials_preserved"] == row["equal_initials"] == 10
    selected = row["selected_initials"]
    assert selected["(6, 6)"]["terminal"] == [6.0, 6.0]
    assert selected["(4, 4)"]["terminal"] == [4.0, 4.0]


def test_best_response_and_undercut_drive_unequal_starts_to_floor(result):
    for rule in ("simultaneous_myopic_br", "mechanical_undercut", "match_if_equal_else_undercut"):
        row = result["closed_loop_counterfactual"][rule]
        assert row["unequal_initials_converge_to_floor"] == 90


def test_held_out_imitation_matches_are_approximate_not_exact(result):
    copy_rate = result["held_out_action_match"]["match_if_equal_else_copy_rival"]["mean_assessment_match_rate"]
    undercut_rate = result["held_out_action_match"]["match_if_equal_else_undercut"]["mean_assessment_match_rate"]
    assert copy_rate == pytest.approx(0.875)
    assert undercut_rate == pytest.approx(0.86875)
    assert not result["held_out_action_match"]["match_if_equal_else_copy_rival"]["cannot_exclude_as_exact_generator"]

