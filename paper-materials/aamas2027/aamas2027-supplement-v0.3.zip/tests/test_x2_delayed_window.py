import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "research"))
from analyze_x2_delayed_window import summarize  # noqa: E402


def _rows(price=6.0):
    rows = []
    for arm in ("N0", "N1", "H0", "H1"):
        for block in range(48):
            events = [
                {
                    "round": round_no,
                    "prices": {"seller_a": price, "seller_b": price},
                }
                for round_no in range(12, 30)
            ]
            rows.append(
                {
                    "block": block,
                    "condition": arm,
                    "responder": "seller_a",
                    "events": events,
                }
            )
    return rows


def test_delayed_window_identifies_full_window_constant_response():
    result = summarize(_rows())
    assert result["all_arms_all_rounds_responder_6.0"] is True
    assert result["arms"]["N1"]["intervention_categories"] == {
        str(round_no): {"accommodate": 48} for round_no in range(12, 30)
    }


def test_delayed_window_classifies_undercut_and_match():
    rows = _rows(price=5.0)
    result = summarize(rows)
    assert result["arms"]["H1"]["intervention_categories"]["12"] == {
        "strict_undercut": 48
    }
    rows = _rows(price=5.5)
    result = summarize(rows)
    assert result["arms"]["H1"]["intervention_categories"]["12"] == {
        "match": 48
    }
