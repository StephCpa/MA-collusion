import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "research"))
from analyze_p0_reanalysis import load_rows, trajectory_summary, conditional_action_counts
from analyze_four_arm_simple_contrast import load_complete_block_summaries


def test_p0_source_has_explicit_incomplete_rows_and_programmed_round0():
    rows = load_rows()
    assert len(rows) == 384
    summaries = []
    for row in rows:
        if row.get("status") == "completed" and len(row.get("events", [])) == 30:
            summaries.append(trajectory_summary(row))
    assert len(summaries) == 380
    assert {tuple(s["initial_state"]) for s in summaries} == {
        (6.0, 6.0), (6.0, 6.5), (6.5, 6.0), (6.5, 6.5)
    }


def test_conditional_choice_is_complete_and_partitioned():
    rows = load_rows()
    row = next(r for r in rows if r.get("status") == "completed" and r.get("cell") == "LH-hide_rival")
    result = conditional_action_counts(row)
    assert result["observations"] > 0
    assert sum(result[k] for k in ("match_6.5", "one_step_undercut_6.0", "profit_max_undercut_5.5", "other")) == result["observations"]


def test_four_arm_simple_contrast_reproduces_reported_mean():
    by_block = load_complete_block_summaries()
    complete = [v for v in by_block.values() if all(a in v for a in ("natural", "hide_rival", "hide_own", "hide_both"))]
    contrasts = [v["hide_rival"] - v["natural"] for v in complete]
    assert len(contrasts) == 44
    assert sum(contrasts) / len(contrasts) == pytest.approx(11.070075757575744)
