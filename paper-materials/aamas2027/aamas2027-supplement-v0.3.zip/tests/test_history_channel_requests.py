import json
import errno
import socket
import ssl
import sys
import threading
import urllib.error
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'research'))
from history_channel_requests import RequestLedger, dispatch_once, ArmRequestFailure, StudyRequestFailure, classify
from history_channel_calibration_cases import build_cases
from history_channel_requests import error_diagnostic


def response(price=4.5,model='deepseek-flash'):
    return {'model':model,'usage':{'prompt_tokens':10,'completion_tokens':5},
        'choices':[{'finish_reason':'tool_calls','message':{'tool_calls':[{'function':{
            'name':'choose_price','arguments':json.dumps({'price':price})}}]}}]}


def body(): return build_cases()['cases'][0]['request']


def test_pre_dispatch_persistence_and_duplicate_refusal(tmp_path):
    p=tmp_path/'requests.jsonl'; ledger=RequestLedger(p,100)
    def sender(b):
        assert json.loads(p.read_text().splitlines()[-1])['event']=='reserved'
        return response()
    assert dispatch_once(ledger,'a',body(),50,sender,lambda a,b:a+b)==4.5
    assert ledger.exposure()==15
    terminal=json.loads(p.read_text().splitlines()[-1])
    assert terminal['price']==4.5 and terminal['usage']=={'prompt_tokens':10,'completion_tokens':5}
    with pytest.raises(StudyRequestFailure): dispatch_once(ledger,'a',body(),50,sender,lambda a,b:15)
    with pytest.raises(FileExistsError): RequestLedger(p,100)


def test_concurrent_reservations_cannot_oversubscribe(tmp_path):
    ledger=RequestLedger(tmp_path/'r',100)
    barrier=threading.Barrier(2)
    def worker(i):
        barrier.wait()
        try: ledger.reserve(str(i),60); return True
        except StudyRequestFailure: return False
    with ThreadPoolExecutor(2) as pool:
        assert sum(pool.map(worker,range(2)))==1
    assert ledger.exposure()==60 and ledger.halted


def test_timeout_keeps_reservation_no_retry(tmp_path):
    ledger=RequestLedger(tmp_path/'r',100); calls=[]
    def fail(b): calls.append(1); raise TimeoutError()
    with pytest.raises(ArmRequestFailure): dispatch_once(ledger,'a',body(),50,fail,lambda a,b:15)
    assert len(calls)==1 and ledger.exposure()==50
    assert not ledger.halted


@pytest.mark.parametrize('code',[401,403,429,503])
def test_http_errors_stop(code):
    assert classify(urllib.error.HTTPError('https://invalid',code,'error',{},None))=='study_stop'


@pytest.mark.parametrize('kind',['usage','identity','overrun','programming'])
def test_fatal_paths(tmp_path,kind):
    ledger=RequestLedger(tmp_path/'r',100)
    def sender(b):
        if kind=='programming': raise RuntimeError('not persisted')
        r=response(model='wrong' if kind=='identity' else 'deepseek-flash')
        if kind=='usage': del r['usage']
        return r
    with pytest.raises(StudyRequestFailure):
        dispatch_once(ledger,'a',body(),50,sender,lambda a,b:120 if kind=='overrun' else 15)
    assert ledger.halted
    assert ledger.exposure()==({'usage':50,'identity':15,'overrun':120,'programming':50}[kind])


@pytest.mark.parametrize('price',[True,4.25,'4.5',float('nan')])
def test_bad_output_charged_but_arm_fails(tmp_path,price):
    ledger=RequestLedger(tmp_path/'r',100)
    with pytest.raises(ArmRequestFailure): dispatch_once(ledger,'a',body(),50,lambda b:response(price),lambda a,b:15)
    assert ledger.exposure()==15 and not ledger.halted


def test_all_calibration_answers_and_hidden_identity():
    cases=build_cases()['cases']
    assert len(cases)==64 and len({c['id'] for c in cases})==64
    assert sum(c['expected_price']==2 for c in cases)==32
    for c in cases:
        data=json.loads(c['request']['messages'][1]['content'])
        observed=data['complete_public_price_history'][-1][c['target']]
        assert c['expected_price']==(2 if observed is None else observed)
        assert 'expected_price' not in json.dumps(c['request'])
    assert cases[0]['expected_price']==4.5
    assert cases[32]['expected_price']==6.5


def test_64_case_fake_sender_gate(tmp_path):
    ledger=RequestLedger(tmp_path/'r',6400)
    for c in build_cases()['cases']:
        def sender(b):
            data=json.loads(b['messages'][1]['content'])
            value=data['complete_public_price_history'][-1][data['read_column']]
            return response(2 if value is None else value)
        assert dispatch_once(ledger,c['id'],c['request'],100,sender,lambda a,b:15)==c['expected_price']
    assert len(ledger.rows)==64 and ledger.exposure()==960
    assert not ledger.halted


@pytest.mark.parametrize('inner,expected',[
    (TimeoutError('secret'),'arm_failure'),
    (ConnectionResetError('secret'),'arm_failure'),
    (OSError(errno.EPIPE,'secret'),'arm_failure'),
    (socket.gaierror(socket.EAI_AGAIN,'secret'),'arm_failure'),
    (socket.gaierror(socket.EAI_NONAME,'secret'),'study_stop'),
    (ssl.SSLCertVerificationError(1,'secret'),'study_stop'),
    (ssl.SSLError(1,'secret'),'study_stop'),
    (OSError(errno.EACCES,'secret'),'study_stop'),
    ('timeout secret','study_stop'),
    (ConnectionRefusedError('secret'),'study_stop'),
])
def test_wrapped_transport_classification_and_redaction(inner,expected):
    result=error_diagnostic(urllib.error.URLError(inner))
    assert result['classification']==expected
    assert 'secret' not in json.dumps(result)


def test_nested_fatal_precedence_and_cycles():
    exc=urllib.error.URLError(urllib.error.URLError(TimeoutError()))
    assert classify(exc)=='arm_failure'
    exc.__cause__=urllib.error.HTTPError('https://secret',503,'secret',{},None)
    assert classify(exc)=='study_stop'
    assert 'secret' not in json.dumps(error_diagnostic(exc))
    cycle=urllib.error.URLError('secret'); cycle.reason=cycle
    assert classify(cycle)=='study_stop'
    assert len(error_diagnostic(cycle)['chain'])==1


@pytest.mark.parametrize('all_fail',[False,True])
def test_wrapped_timeout_study_continuation_and_circuit(tmp_path,all_fail):
    from history_channel_study import plan, execute_offline, programmatic_runner
    from history_channel_live import audited_dispatch
    schedule=plan(); schedule['blocks']=schedule['blocks'][:1]
    ledger=RequestLedger(tmp_path/'requests.jsonl',1000000)
    calls=[]
    def sender(payload):
        calls.append(1)
        raise urllib.error.URLError(TimeoutError('secret bearer token'))
    def runner(block,arm,emit):
        if all_fail or not calls:
            audited_dispatch(ledger,arm,body(),sender,tmp_path/'audit')
        programmatic_runner('focal')(block,arm,emit)
    result=execute_offline(schedule,tmp_path/'study',runner)
    assert len(calls)==(3 if all_fail else 1)
    assert ledger.exposure()==20000*len(calls)
    assert [r['status'] for r in result['arms']]==(
        ['failed','failed','failed','not_started'] if all_fail else
        ['failed','complete','complete','complete'])
    if all_fail: assert result['stop_reason']=='consecutive_arm_failures'
    assert not ledger.halted  # The study circuit is separate from request halt.
    records=[json.loads(line) for line in ledger.path.read_text().splitlines()]
    failures=[r for r in records if r['event']=='finished']
    assert all(r['diagnostic']['classification']=='arm_failure' for r in failures)
    assert 'secret' not in ledger.path.read_text()
    for path in (tmp_path/'audit').glob('*/failure.json'):
        assert json.loads(path.read_text())['diagnostic']['classification']=='arm_failure'
        assert 'secret' not in path.read_text()
