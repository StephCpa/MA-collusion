import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "research"))
from x1_best_response_probe import (  # noqa: E402
    GRID,
    build_manifest,
    current_best_response,
    mock_payload,
    mock_rows,
    parse_payload,
    selftest,
    validate_manifest,
    audited_call,
)
from history_channel_requests import RequestLedger, StudyRequestFailure


def test_payoff_best_response_and_manifest_balance():
    assert current_best_response(6.0) == 5.5
    assert current_best_response(6.5) == 5.5
    manifest = build_manifest(123)
    validate_manifest(manifest)
    assert len(manifest["slots"]) == 576
    assert len({slot["logical_id"] for slot in manifest["slots"]}) == 576


def test_forced_function_parser_and_model_identity():
    assert parse_payload(mock_payload(5.5)) == 5.5
    assert parse_payload(mock_payload(5.5, "deepseek-v4.1-flash")) == 5.5
    with pytest.raises(Exception):
        parse_payload(mock_payload(5.5, "other-model"))
    with pytest.raises(Exception):
        parse_payload(mock_payload(5.25))


def test_mock_report_is_deterministic():
    first = selftest()
    second = selftest()
    assert json.dumps(first, sort_keys=True) == json.dumps(second, sort_keys=True)


def test_mock_rows_cover_all_registered_cells():
    manifest = build_manifest()
    rows = mock_rows(manifest)
    assert len(rows) == 576
    assert {row["rival_price"] for row in rows} == {6.0, 6.5}
    assert {row["horizon"] for row in rows} == {"terminal", "continuing"}
    assert all(row["price"] in GRID for row in rows)


def test_transport_failure_is_reserved_and_terminal(tmp_path):
    manifest = build_manifest()
    slot = manifest["slots"][0]
    ledger = RequestLedger(tmp_path / "requests.jsonl", 100_000)

    def sender(_body):
        raise TimeoutError("synthetic timeout")

    with pytest.raises(StudyRequestFailure):
        audited_call(ledger, slot, sender, tmp_path)
    assert ledger.exposure() == 20_000
    assert ledger.halted
    events = [json.loads(line) for line in (tmp_path / "requests.jsonl").read_text().splitlines()]
    assert events[-1]["event"] == "finished"
    assert events[-1]["status"] == "transport_unknown"
