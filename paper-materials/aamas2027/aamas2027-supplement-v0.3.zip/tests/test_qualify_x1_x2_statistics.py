import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from research.qualify_x1_x2_statistics import load, zero_event_upper


def test_zero_event_bound_matches_registered_calibration():
    assert math.isclose(zero_event_upper(48), 0.06050340934889431, rel_tol=0, abs_tol=1e-15)
    assert math.isclose(zero_event_upper(144), 0.02058879229949584, rel_tol=0, abs_tol=1e-15)


def test_frozen_x1_x2_denominators_and_ranges():
    result = load()
    assert result["x1"]["terminal_draws_per_cell"] == 144
    assert result["x1"]["terminal_cluster_count_per_cell"] == 48
    assert math.isclose(result["x1"]["terminal_cluster_wilson_lower_reference"], 0.9258998703338824)
    assert result["x2"]["complete_blocks"] == 48
    assert result["x2"]["cut5_interaction_ci"] == [0, 0]
    assert result["controlled_initial"]["D_asym"]["planned_completion_range"] == [
        0.6228298611111143, 1.0460069444444475
    ]
    assert result["controlled_initial"]["J"]["planned_completion_range"] == [
        -1.2065972222222203, 1.6710069444444464
    ]
