import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1]))
from research.x2_forced_deviation import *

def test_manifest_offline_and_schedule():
    m=build_manifest(); assert m["paid_calls_authorized"] is False; assert m["trajectories"]==192

def test_self_test(): assert self_test()["passed"]

def test_ledger_complete_and_no_retry():
    es=[LedgerEntry(b,c,"A" if b<=24 else "B") for b in range(1,49) for c in CONDITIONS]
    result=validate_ledger(es); assert result["valid"]; assert result["forced_counts"]=={"A":96,"B":96}

def test_ledger_rejects_retry():
    e=LedgerEntry(1,"N0","A",retries=1); assert not validate_ledger([e])["valid"]

def test_synthetic_interaction_and_equal_zero():
    rows=[{"condition":c,"round11":(5.0 if c=="N1" else 6.0)} for c in CONDITIONS for _ in range(10)]
    assert analyze_interaction(rows)["cut5_interaction"]==1.0
    rows=[{"condition":c,"round11":6.0} for c in CONDITIONS for _ in range(10)]
    assert analyze_interaction(rows)["cut5_interaction"]==0

def test_hidden_surface_has_no_rival_or_outcomes():
    t=synthetic_trajectory("H1")
    assert all("rival_posted_prices" not in e["visible_history"] for e in t["events"])
    assert all("outcome" not in e["visible_history"] for e in t["events"])
