import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "research"))
import x2_forced_deviation_live as live  # noqa: E402


def test_paid_runner_plan_is_balanced_and_exact():
    plan = live.build_plan(123)
    live.validate_plan(plan)
    assert plan["planned_trajectories"] == 192
    assert plan["planned_model_calls"] == 7680
    assert sum(b["forced_seller"] == "A" for b in plan["blocks"]) == 24
    assert sum(b["forced_seller"] == "B" for b in plan["blocks"]) == 24


def test_offline_selftest_has_no_paid_authorization():
    result = live.offline_selftest()
    assert result["passed"]
    assert result["planned_calls"] == 7680
