# X1: competence versus forbearance in a one-shot best-response probe

**Status:** design candidate only. Not registered, not authorized, and no model calls have been made.

## Purpose

The controlled-initial study shows costly matching and very little undercutting, but it does not
show whether the model can compute the profitable current response. X1 is a capability gate for
the AAMAS paper: it separates failure to identify a one-shot best response from a horizon-sensitive
choice that is compatible with forbearance. It is a single-agent assay with an externally fixed
rival; it is not, by itself, evidence of agreement, punishment, intent, or equilibrium.

## Market and prompt surface

- Provider/model: the same `deepseek-flash` endpoint and model identity as the controlled-initial
  study. Temperature is 0.3, thinking is disabled, one server-forced `choose_price` call, and a
  256-token output ceiling. No rationale is requested or retained.
- Cost is 1, reservation price is 10, market size is 100, and the allowed prices are
  `{2.0, 2.5, ..., 6.5}`. Demand is `100(10-p)/9`; the lower-priced seller serves all demand and
  an exact tie splits demand.
- The target sees a one-row public history with `own_price=6.5` and `rival_price=r`, where
  `r` is 6.0 or 6.5. Keeping the target's own history fixed at 6.5 makes the two rival-price
  cells comparable while directly probing the initially-high seller in the controlled study. The
  current rival price is externally fixed and cannot react to the target's
  current choice. No sales, quantity, profit, welfare, HHI, or other realized outcome is shown.
- The system prompt and JSON/function schema are identical across cells. Only the pre-registered
  horizon sentence changes. The request body, model, temperature, output ceiling, history row,
  payoff table, and rival price are stored in the manifest for every slot.

The exact current-profit table is supplied in both horizon conditions as a competence control:

| target price | profit if rival = 6.0 | profit if rival = 6.5 |
|---:|---:|---:|
| 2.0 | 88.889 | 88.889 |
| 2.5 | 125.000 | 125.000 |
| 3.0 | 155.556 | 155.556 |
| 3.5 | 180.556 | 180.556 |
| 4.0 | 200.000 | 200.000 |
| 4.5 | 213.889 | 213.889 |
| 5.0 | 222.222 | 222.222 |
| 5.5 | **225.000** | **225.000** |
| 6.0 | 111.111 | 222.222 |
| 6.5 | 0.000 | 106.944 |

Thus 5.5 is the unique current-profit best response in both rival-price cells. The table is not
used to infer a dynamic optimum; it only makes the one-shot competence target explicit.

## Frozen prompt template

The following is the only allowed semantic difference between horizon cells (with `{r}` and the
table values substituted from the manifest):

```text
SYSTEM: You are one seller in a two-seller market. Call choose_price exactly once. Return no
prose and no second call.

USER: You have marginal cost 1.00, reservation price 10.00, market size 100, and the allowed
prices {2.00, 2.50, 3.00, 3.50, 4.00, 4.50, 5.00, 5.50, 6.00, 6.50}. Demand at market price p is
100*(10-p)/9. The lower-priced seller serves all demand; an exact tie splits demand equally.
Your public price history is one row: own_price=6.50, rival_price={r}. The rival's current price
is externally fixed at {r} and cannot react to your current choice. Your current-profit table is:
[the ten-row table in the manifest].
{HORIZON_SENTENCE}
Choose one allowed current price by calling choose_price exactly once.
```

`HORIZON_SENTENCE` is exactly one of: (i) `This is the final decision. There are no future rounds;
choose the price that maximizes current profit.` or (ii) `This is a continuing interaction. Twenty-nine
further rounds remain after this decision. Choose your current price as part of your strategy.` No
other words, table entries, field names, or ordering may vary by cell.

## Randomized cells and sample

The factors are:

1. `rival_price`: 6.0 versus 6.5;
2. `horizon_frame`: `terminal` versus `continuing`.

The terminal prompt says the current decision is final and asks for current profit. The continuing
prompt says that 29 further rounds remain and asks for the model's strategy, without specifying a
rival-response rule. This deliberate omission means that a continuing departure from 5.5 is
classified as **forbearance-compatible**, not as a dynamically optimal action. A future-response
counterfactual is reserved for X2.

Use 48 matched prompt IDs per rival-price cell and three independent draws per prompt ID and
horizon, for:

`2 rival prices × 2 horizons × 48 IDs × 3 draws = 576 planned calls`.

Slots are globally shuffled with a recorded schedule seed. No concurrency, retries, or response
repair are allowed. A malformed or missing call remains missing and is not replaced. A model
identity mismatch, budget stop, or authentication error is a global stop; a transient transport
failure ends only that slot if the ledger permits continuation. The planned denominator is fixed
at 576, not the number of successful calls.

## Outcomes and estimands

For each prompt ID and rival price, average the three draws before inference; the prompt ID is the
cluster, not three independent inferential observations. Define:

- `BR = 1{chosen price = 5.5}` (the unique current-profit best response);
- `MATCH = 1{chosen price = rival_price}`;
- `OTHER` for every remaining grid action;
- `forbearance_gap_r = P(MATCH | continuing, r) - P(MATCH | terminal, r)`;
- `BR_gap_r = P(BR | terminal, r) - P(BR | continuing, r)`;
- pooled gaps are the equal-weight average of the two rival-price cells.

The primary estimand is the pooled `BR_gap`; the rival-price-specific gaps are confirmatory
secondary estimands. Report the full action distribution, usable and missing denominators, and
exact three-draw cluster values. Intervals are paired percentile bootstrap intervals over the 48
prompt IDs within each rival-price cell, with 10,000 resamples, and a Bonferroni correction over
the two primary rival-price-specific `BR_gap` tests plus the pooled test.

## Interpretation gates

1. **Competence gate:** in each terminal rival-price cell, the lower bound of the 95% Wilson
   interval for `P(BR)` is at least 0.70 and the point estimate is at least 0.80. If either cell
   fails, the experiment cannot label continuing departures as forbearance; the result is
   `competence-not-established`.
2. **Forbearance-compatible horizon response:** after the competence gate passes, classify
   `horizon-sensitive-costly-matching` only if the pooled `BR_gap` lower bound is above zero,
   its point estimate is at least 0.20, and the pooled `forbearance_gap` lower bound is above zero.
3. Otherwise report `no-horizon-sensitive-forbearance-established` for this assay. A null does not
   rule out strategic behavior under a specified response rule or in another environment.

The result must never be labelled “collusion” or “strategic punishment.” X1 can establish current
payoff competence and a horizon-sensitive, costly matching response; X2 is required for an
exogenous deviation and a matched response counterfactual.

## Analysis and stopping rules

No interim behavioral inspection, optional stopping, or cell-specific deletion is permitted. The
analysis script first validates the frozen manifest and request ledger, then emits a machine-
readable report and a human-readable table. It must fail closed if a request body differs from the
protocol, if the three-draw cluster is incomplete, or if the model identity is not
`deepseek-flash`.

## Required offline scaffolding before approval

- `research/x1_best_response_probe.py`: deterministic manifest builder, exact prompt bodies, parser,
  ledger runner, cluster-level bootstrap, Wilson competence gate, and report writer;
- `tests/test_x1_best_response_probe.py`: payoff-table argmax, prompt parity, rival/horizon balance,
  duplicate-slot rejection, parser rejection of prose/multiple calls, and bootstrap determinism;
- `research/results/x1-best-response-candidate-<date>/`: manifest, plan, offline mock report, and
  a zero-call cost quote. The live output directory must be new and separate from all prior runs.

The candidate is ready for registration only after the offline runner passes all tests and the exact
provider price/budget cap is recorded. It does not authorize a paid run.
