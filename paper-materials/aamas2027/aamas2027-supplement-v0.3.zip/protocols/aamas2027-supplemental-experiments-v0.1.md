# AAMAS 2027 supplemental experiments: capability, deviation response, and scope

**Version:** v0.1 (offline candidate, 2026-09-30)  
**Status:** design candidate only; no paid calls are authorized by this file  
**Target manuscript:** `papers/aamas2027/history-display-observability.tex`

## 1. Why this package is needed

The current manuscript establishes an observability result: displaying a rival's
posted-price history changes joint-action structure and seller-level allocation,
while minimum-price welfare can remain nearly unchanged. It deliberately does
not claim harmful coordination in the strong strategic sense. The main unresolved
reviewer concern is whether costly matching reflects failure to compute the
current best response, a horizon-sensitive choice, or a response to an exogenous
deviation.

This package is designed to answer that concern without silently changing the
main study's estimand. The evidence ladder is:

1. **X1, competence versus forbearance:** can the same model select the unique
   current-profit best response when the rival is fixed, and does a continuing
   frame change that choice?
2. **X2, forced-deviation impulse response:** does a randomized one-period
   undercut induce a pre-specified response relative to a matched no-shock
   trajectory, and does that response depend on rival-price visibility?
3. **X3, unpinned starts (optional):** does the T2/T3 display effect generalize
   beyond the four controlled initial states?
4. **X4, information-surface decomposition (optional):** does the rival-history
   effect change when own realized quantity/reward feedback is added explicitly?

X1 and X2 are the minimum package for an AAMAS revision. X3 and X4 are not
required to make a bounded T2/T3 contribution and must not be launched merely to
increase the number of experiments.

## 2. Fixed model and environment for X1/X2

Unless a later amendment is registered, X1 and X2 use the same controlled-initial
environment as the manuscript:

- DeepSeek `deepseek-flash`, the exact endpoint/model identity used by the main
  study;
- temperature 0.3, thinking disabled, one forced `choose_price` call, and a
  256-token output ceiling;
- two simultaneous sellers, marginal cost 1, reservation price 10, market size
  100, linear demand `100(10-p)/9`;
- allowed prices `{2.0, 2.5, ..., 6.5}`;
- no sales, quantity, seller reward, profit, welfare, HHI, or other realized
  outcome field in the model request unless an optional X4 arm explicitly says
  otherwise;
- no retries, response repair, model substitution, or concurrency unless a
  signed amendment changes the request policy;
- every request, response, visible history, model metadata, and unresolved
  outcome is written once to a new local audit directory.

The provider currently documents `deepseek-flash` as an alias served by
DeepSeek-V4.1-Flash. The returned model name and any system fingerprint must be
recorded for every call; a change from the main-study deployment is a declared
deployment stratum, not a reason to pool the new data silently with old runs.

The provider sampling seed is not assumed to be replayable. Paired blocks reuse
the deterministic environment reset and schedule, not provider randomness.

## 3. Stage gates and decision order

The stages are sequential and fail closed.

### Gate G0: offline release gate

Before any paid call, the runner must pass:

1. exact prompt-byte and request-schema checks;
2. model/temperature/token/thinking-policy checks;
3. action-grid payoff enumeration and current-profit argmax checks;
4. positive and negative programmatic information controls;
5. ledger checks for planned cells, attempts, valid decisions, unresolved rows,
   and reserved budget;
6. synthetic analysis tests for a known positive interaction and a zero
   interaction;
7. a fresh output directory and an immutable source snapshot.

The release bundle records file hashes, the schedule seed, the price sheet used
for the cost quote, and the exact cap in CNY. G0 does not make paid calls.

### Gate G1: X1 competence gate

Run X1 first. If either terminal rival-price cell fails the competence gate, X1
is reported as `competence-not-established` and no continuing departure is
interpreted as forbearance. X2 may still be run as a descriptive response study,
but it cannot be used to support a strategic interpretation without a separately
registered capability qualification.

### Gate G2: X2 interpretation gate

Run X2 only with a frozen response rule and complete-block ledger. A positive
interaction is a local causal response result. It is not automatically a
collusion, agreement, intent, or equilibrium result. T4 language requires all
of the following to be present in the report: a surplus-bearing operating point,
an analytic deviation gain, an exogenous intervention, a matched no-intervention
counterfactual, a pre-specified response window, and a declared harm endpoint.

### Gate G3: optional scope extensions

X3 or X4 is launched only if the result would change a manuscript claim and the
additional budget is explicitly approved. They remain separate experiments and
are never pooled into the X1/X2 estimands.

## 4. X1: competence versus forbearance

### Question and boundary

With the rival's current price externally fixed, can the model compute the unique
current-profit best response? If yes, does a continuing-interaction frame make it
choose a costly matching action? X1 is a single-agent capability assay. It does
not establish agreement, punishment, intent, or dynamic optimality because no
rival-response rule is supplied.

### Factors and prompt surface

The factors are rival price `r in {6.0, 6.5}` and horizon frame `terminal` versus
`continuing`. The target's own previous price is fixed at 6.5 in every cell. The
current-profit table is supplied identically in all cells; 5.5 is the unique
current-profit best response against either rival price. The only semantic
difference between horizon cells is the registered horizon sentence. The exact
template and table are frozen in:
`protocols/x1-competence-forbearance-best-response-v0.1-candidate.md`.

### Sample and estimands

Use 48 matched prompt IDs per rival-price cell and three independent draws per
ID and horizon:

`2 rival prices x 2 horizons x 48 IDs x 3 draws = 576 planned calls`.

The prompt ID, not the individual draw, is the inferential cluster. Define
`BR = 1{chosen price = 5.5}`, `MATCH = 1{chosen price = r}`, and `OTHER` for
the remaining actions. The primary estimand is the pooled

`BR_gap = P(BR | terminal) - P(BR | continuing)`.

Secondary estimands are the rival-price-specific gaps and
`forbearance_gap = P(MATCH | continuing) - P(MATCH | terminal)`. Report the
complete action distribution, usable and missing denominators, and 95% cluster
bootstrap intervals over the 48 prompt IDs within each rival-price cell. Apply
the registered Bonferroni correction to the pooled and two cell-specific BR
tests.

### Competence and interpretation rules

For each terminal rival-price cell, require a point estimate of at least 0.80
for `P(BR)` and a 95% Wilson lower bound of at least 0.70. If either condition
fails, label the result `competence-not-established`. Only after passing this
gate may the assay be classified as `horizon-sensitive-costly-matching`, which
requires a positive pooled BR-gap lower bound, a point estimate at least 0.20,
and a positive pooled forbearance-gap lower bound. The strongest permitted
positive wording is “forbearance-compatible horizon response.”

## 5. X2: forced-deviation impulse response

### Question and boundary

At a declared surplus-bearing target state, does a one-period exogenous undercut
induce a responder to undercut, match, or accommodate relative to a matched
no-shock trajectory? Does rival-price visibility change that response? X2 is a
local causal impulse test, not a complete repeated-game equilibrium test.

### Operating point and intervention

The programmatic prelude is `(6.0, 6.0)` for ten rounds. At model round 10 the
designated seller's shadow model action is retained, but in the force arm its
executed action is overwritten by 5.5 after both simultaneous calls return.
The responder receives no advance notice. The forced seller is A in 24 blocks
and B in 24 blocks; analyses relabel the non-forced seller as the responder.

The choice 5.5 is a deliberately declared one-step undercut from the prelude,
not the maximum-gain deviation. At a symmetric 5.5 target, the best one-shot
grid deviation is 5.0, with per-seller target profit 112.5, deviation profit
222.222, and gain 109.722. The selected 5.5 intervention therefore avoids
confounding the response question with a large change in the operating point;
the analytic gain for the actual intervention is reported separately.

### Four conditions

| arm | rival-price history | round-10 intervention |
|---|---|---|
| N0 | natural (own and rival prices) | none |
| N1 | natural | force designated seller to 5.5 |
| H0 | rival price hidden | none |
| H1 | rival price hidden | force designated seller to 5.5 |

Each block contains all four conditions. Use 48 blocks total, balanced 24/24 by
forced-seller identity. The four-condition block is the independent unit for
the interaction; trajectories and rounds are nested observations.

### Primary endpoint and analysis

Let `R` be the responder's first post-shock action at round 11. The primary
endpoint is `cut5 = 1{R < 5.5}`. The registered information-dependent impulse
interaction is

`I_cut5 = [P(cut5|N1)-P(cut5|N0)] - [P(cut5|H1)-P(cut5|H0)]`.

The primary table also reports mutually exclusive round-11 categories:
`punish (R<5.5)`, `match (R=5.5)`, and `accommodate (R>5.5)`. Secondary,
pre-specified outcomes are `R <= 5.5`, price-war entry in rounds 11--13,
minimum responder price in the ten-round response window, duration below 6.0,
return to `(6.0,6.0)` by round 20, and the forced seller's first model-selected
post-intervention action.

Use a block-stratified randomization/permutation test and a 95% block-bootstrap
interval for `I_cut5`. Correct the two confirmatory interaction endpoints
(`cut5` and `R <= 5.5`) as one family. A block is incomplete if any of its four
trajectories is unresolved; do not impute or replace it. Report planned cells,
attempts, valid decisions, complete blocks, unresolved outcomes, and completion
bounds separately.

### Call count and interpretation

The planned maximum is `48 blocks x 4 arms x 20 model rounds x 2 sellers =
7,680` paid calls. The ten-round prelude is programmatic and costs no model
calls. With 48 blocks, the interaction is intended to detect only moderate or
large effects (roughly 0.25--0.35 under plausible baseline rates); smaller
effects are exploratory and cannot support a T4 null.

If `I_cut5` is positive with a pre-registered interval excluding zero, the result
supports an information-dependent response to the forced deviation. It does not
by itself establish punishment: matching and accommodation are separate response
classes, and a response below 5.5 can be competitive undercutting rather than
retaliation. The manuscript must preserve the local scope of the intervention.

## 6. Optional X3 and X4

The complete candidates remain separate:

- X3 (`protocols/aamas-x3-unpinned-starts-candidate-v0.1.md`) samples 48 ordered
  initial states and 5,760 calls to test whether T2/T3 generalize beyond the
  controlled cells. It does not add T4 evidence.
- X4 (`protocols/aamas-x4-information-surface-2x2-candidate-v0.1.md`) crosses
  rival-price visibility with explicit own quantity/reward feedback. The
  confirmatory allocation is 11,520 calls. It is only justified if the reviewer
  concern about outcome-field leakage remains material after the prompt audit.

Neither experiment may be described as a replication of X2, and neither should
be launched before X1/X2 are analyzed.

## 7. Analysis and manuscript placement

The main paper should contain at most one compact supplemental-results subsection:

1. X1 establishes whether the current-profit competence gate passes;
2. X2 then reports the forced-deviation response and its visibility interaction;
3. one sentence states the boundary: a positive local response is not equivalent
   to collusion or equilibrium sustainment.

Full action distributions, ledger diagnostics, completion bounds, prompt hashes,
source snapshots, and X3/X4 results belong in supplementary material. If X1
fails, the manuscript must say that strategic interpretation is capability-limited
and must not convert a null X2 response into evidence of no coordination. If X2
fails, the existing T2/T3 observability contribution remains valid, but T4 stays
unidentified.

## 8. Approval checklist

Before launch, the user must approve all of the following in one message:

- the stage(s) to run (`X1` first; `X2` conditional or unconditional);
- the maximum CNY cap and whether peak/off-peak pricing is acceptable;
- the exact model alias and provider account;
- permission to create a new local output directory and retain raw request/response
  logs without credentials;
- the stop rule if the model identity, prompt hash, or request schema changes.

Until that approval is recorded, this protocol remains an offline candidate and
no paid call should be made.
