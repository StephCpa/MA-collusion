# AAMAS 2027 supplementary material (anonymous staging package, v0.2)

This package contains the protocols, offline analysis scripts, sanitized run summaries, and trajectory records supporting the manuscript. It excludes raw request directories, private credentials, account identifiers, and local filesystem paths.

The primary registered X2 estimand is the round-11 responder action. The rounds 12--29 delayed-response file is a separate descriptive local-persistence analysis; it is not a T4 test. The P0-derived files and initial-state baseline files are offline sensitivity analyses and do not replace registered estimands.

## Changes in v0.2 (2026-10-01)

- `data/`: the sealed Candidate A (independent replication) trajectory ledger, frozen analysis and status files.
- `tools/candidate_a_structural.py`: reproduces the frozen Candidate A welfare analysis exactly and computes the protocol's structural primary D_tie (0.830, 95% block-t [0.743, 0.917], completion range [0.792, 0.841]); outputs in `analysis/A-confirmation-structural-20261001.*`.
- `analysis/A-confirmation-result-20261001.md`: corrected. Its earlier "equal-price persistence" deltas were hide-minus-natural welfare deltas.
- `tools/observability_certificate.py`: derives the settlement partition and the separating observables, evaluates the T4 operating-point gate, and re-settles all 11,375 recorded replication rounds; outputs in `analysis/observability-certificate.*`.
- `tools/build_fig2_replication.py`: regenerates manuscript Figure 2.
- `research/results/reviewer-revision-20261001/x1-x2-statistical-qualification.md`: the X1 best-response gap is labelled terminal-minus-continuing (values unchanged).
- `research/results/aamas2027-supplement-candidate-20260930/evidence-to-claim-audit.md`: cluster-level Wilson wording; replication, T3a/T3b and operating-point-gate rows.
- `research/results/reviewer-revision-20261001/offline-initial-state-baselines/report.md`: "absorbing" replaced by "persistent".

## Re-run examples

From the package root (Python 3.10+; `matplotlib` only for the figure):

```text
python tools/observability_certificate.py --check
python tools/candidate_a_structural.py --check
python tools/build_fig2_replication.py
python research/x1_best_response_probe.py --offline-selftest
python research/x2_forced_deviation.py --selftest
python research/qualify_x1_x2_statistics.py
```

Scripts under `research/` were written against the authors' project layout (for example `artifacts/...` and `papers/...`) and may need those sealed directories, which are not redistributed. The live runners are included for provenance but require an explicitly configured environment and must not be run from this package during review.
