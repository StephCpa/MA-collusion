# AAMAS 2027 supplementary material (anonymous staging package)

This package contains the protocols, offline analysis scripts, sanitized run summaries, and compact trajectory records supporting the manuscript. It excludes raw request directories, private credentials, account identifiers, and local filesystem paths.

The primary registered X2 estimand is the round-11 responder action. The rounds 12--29 delayed-response file is a separate descriptive local-persistence analysis; it is not a T4 test. The P0-derived files and initial-state baseline files are offline sensitivity analyses and do not replace registered estimands.

Re-run examples (from the repository root):

```text
python research/x1_best_response_probe.py --offline-selftest
python research/x2_forced_deviation.py --selftest
python research/analyze_x2_delayed_window.py --run-dir <x2-run-dir>
python research/analyze_p0_reanalysis.py
python research/analyze_four_arm_simple_contrast.py
python research/initial_state_baseline_sensitivity.py
python research/qualify_x1_x2_statistics.py
```

The live runners are included for provenance but require an explicitly configured environment and must not be run from this package during review.
